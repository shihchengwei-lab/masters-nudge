from pathlib import Path
import json,subprocess,sys,os,threading,time,sqlite3,hashlib,shutil
ROOT=Path(__file__).resolve().parent
CLI=Path(json.loads((ROOT/'plan.json').read_text(encoding='utf-8'))['cli'])
PACKAGE=ROOT/'frozen-plugin'
arm=sys.argv[1];run=ROOT/arm;plan=json.loads((run/'plan.json').read_text(encoding='utf-8'))
lock=threading.Lock();stopped=threading.Event();started=time.monotonic()
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
def save(name,value):
 path=run/name;temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');temp.replace(path)
def emit(kind,text):
 with lock:
  print(text,flush=True)
  with (run/'screen-events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps({'elapsed':round(time.monotonic()-started,3),'wall_time':time.time(),'kind':kind,'text':text},ensure_ascii=False)+'\n')
def toml(value):return json.dumps(value,ensure_ascii=False,separators=(',', '='))
args=[str(CLI),'-c','project_doc_max_bytes=0','-c','features.multi_agent=false','-c','model_reasoning_effort="medium"','--disable','plugins']
env={**os.environ,'CODEX_HOME':str(run/'codex-home'),'PATH':str(CLI.parent)+os.pathsep+os.environ['PATH'],'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1','MASTERS_NUDGE_ACTIVE':'0'}
if arm=='B':
 env.update(MASTERS_NUDGE_DATA_DIR=str(run/'nudge-data'),MASTERS_NUDGE_RUNTIME_DIR=str(PACKAGE),MASTERS_NUDGE_TEST_MODE='1')
 transport={'command':sys.executable,'args':[str(PACKAGE/'mcp_entry.py')],'enabled':True,'required':True,'enabled_tools':['review_patch'],'omit_tools_from':['code_mode','deferred'],'startup_timeout_sec':30,'tool_timeout_sec':1320,'env':{'PYTHONIOENCODING':'utf-8'},'env_vars':['CODEX_HOME','HOME','LOCALAPPDATA','MASTERS_NUDGE_ACTIVE','MASTERS_NUDGE_DATA_DIR','MASTERS_NUDGE_RUNTIME_DIR','MASTERS_NUDGE_TEST_MODE','PATH','USERPROFILE']}
 fields=['hook_event_name','session_id','turn_id','cwd','transcript_path','tool_name','tool_use_id','tool_input','tool_response']
 post=[{'matcher':'^apply_patch$','hooks':[{'type':'mcp_tool','server':'masters_nudge','tool':'review_patch','input':{k:'${'+k+'}' for k in fields},'timeout':1320}]}]
 submit=[{'hooks':[{'type':'command','command':subprocess.list2cmdline([sys.executable,str(PACKAGE/'hook_entry.py'),'--host','codex_cli']),'timeout':120}]}]
 args+=['--enable','hooks','-c','mcp_servers.masters_nudge='+toml(transport),'-c','hooks.PostToolUse='+toml(post),'-c','hooks.UserPromptSubmit='+toml(submit)]
else:args+=['--disable','hooks']
args+=['exec','--ignore-user-config','--ignore-rules']
if arm=='B':args+=['--dangerously-bypass-hook-trust']
args+=['--skip-git-repo-check','--color','always','-s','danger-full-access','-m','gpt-6.1-sol','-C',plan['cwd'],'-o',str(run/'actor-final.txt'),'-']
# No JSON output: capture the real CLI's normally rendered operations / patch output.
save('launch.json',{'command':args,'model':'gpt-6.1-sol','effort':'medium','hooks':arm=='B','timeout_seconds':1800,'display':'actual codex exec output plus passive delivered-hook journal monitor'})
emit('start',f'LIVE ELEMENT RERUN / {arm} / '+('WITH NUDGE' if arm=='B' else 'WITHOUT NUDGE'))
emit('start','Actor: GPT-6.1 Sol medium | '+('Provider: GPT-6.1 Sol medium' if arm=='B' else 'No Provider'))
emit('start','Actual CLI output follows. No replay / invented Actor text.')
# Wait until the orchestrator has attached the screen recorder.
while not (run/'recording-ready').exists():time.sleep(.1)
started=time.monotonic()
emit('recording','Recording attached; submitting the original task now.')
proc=subprocess.Popen(args,cwd=plan['cwd'],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
save('running.json',{'pid':proc.pid,'created_wall':time.time(),'started_at':time.strftime('%Y-%m-%dT%H:%M:%S'),'command':args})
def relay(channel,stream):
 with (run/f'actor-{channel}.txt').open('w',encoding='utf-8') as log:
  for line in stream:
   log.write(line);log.flush();emit(channel,line.rstrip('\n'))
def nudges():
 seen=set();database=run/'nudge-data/feedback.sqlite3'
 while not stopped.is_set():
  if database.exists():
   try:
    with sqlite3.connect(database) as db:
     db.row_factory=sqlite3.Row
     rows=db.execute('SELECT * FROM attempts WHERE finished IS NOT NULL AND delivered=1 ORDER BY started').fetchall()
    for row in rows:
     if row['id'] in seen:continue
     seen.add(row['id']);detail=json.loads(row['detail']);raw=detail.get('raw_output','')
     emit('nudge_received','\n===== ACTUAL NUDGE / delivery receipt recorded =====')
     try:
      feedback=json.loads(raw).get('feedback') or {}
      for key in ['observed','why','structure','required']:emit('nudge_received',key.upper()+': '+str(feedback.get(key,'')))
     except ValueError:emit('nudge_received',raw)
     emit('nudge_received','===== Read-only display of delivered feedback; Actor continues =====\n')
   except sqlite3.Error:pass
  stopped.wait(.1)
threads=[threading.Thread(target=relay,args=('stdout',proc.stdout)),threading.Thread(target=relay,args=('stderr',proc.stderr))]
if arm=='B':threads.append(threading.Thread(target=nudges))
for thread in threads:thread.start()
proc.stdin.write((run/'prompt.txt').read_text(encoding='utf-8'));proc.stdin.close()
fault=''
try:proc.wait(timeout=1800)
except subprocess.TimeoutExpired:
 fault='Original 30-minute Actor deadline exceeded'
 subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True);proc.wait(timeout=20)
stopped.set()
for thread in threads:thread.join(timeout=10)
work=Path(plan['cwd'])
subprocess.run(['git','add','-N','.'],cwd=work,check=True,capture_output=True)
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=work);(run/'final.patch').write_bytes(patch)
records=[]
database=run/'nudge-data/feedback.sqlite3'
if arm=='B' and database.exists():
 with sqlite3.connect(database) as db:
  db.row_factory=sqlite3.Row
  for row in db.execute('SELECT * FROM attempts ORDER BY started'):
   value=dict(row);value['detail']=json.loads(value['detail']);records.append(value)
save('provider-attempts.json',records)
save('result.json',{'arm':arm,'exit_code':proc.returncode,'fault':fault,'actor_seconds':round(time.monotonic()-started,3),'patch_sha256':hashlib.sha256(patch).hexdigest(),'patch_bytes':len(patch),'provider_attempts':len(records),'provider_feedback_delivered':sum(x['outcome']=='feedback' and x['delivered']==1 for x in records),'do_not_retry_on_outcome':True})
emit('finished',f'Actor finished: exit={proc.returncode}; patch bytes={len(patch)}; feedback delivered='+str(sum(x['outcome']=='feedback' and x['delivered']==1 for x in records)))
emit('finished','Original answer and raw session retained. Acceptance has not been judged yet.')
(run/'actor-done').write_text('done',encoding='utf-8')
while not (run/'stop-window').exists():time.sleep(.2)
