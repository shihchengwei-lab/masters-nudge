from pathlib import Path
import json,subprocess,hashlib,zipfile,shutil
ROOT=Path(r'E:\masters-nudge-benchmark\element-live-capture-20261012')
REPO=Path(r'C:\Users\kk789\Desktop\GH_repos\masters-nudge')
SOURCE=Path(r'D:\masters-nudge-benchmark\round-10-calibration\cases\element-sessions')
CLI=Path(r'C:\Users\kk789\AppData\Roaming\npm\node_modules\@openai\codex\node_modules\@openai\codex-win32-x64\vendor\x86_64-pc-windows-msvc\bin\codex.exe')
BASE='7a33818bd7ec89c21054691afcb6db2fb2631e14'
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def git(*args,cwd=SOURCE):return subprocess.check_output(['git',*args],cwd=cwd)
source_index=Path(git('rev-parse','--path-format=absolute','--git-path','index').decode().strip())
source_fingerprints={'diff_sha256':hashlib.sha256(git('diff','--binary','HEAD')).hexdigest(),'index_sha256':hashlib.sha256(source_index.read_bytes()).hexdigest(),'status':git('status','--porcelain=v1').decode()}
shutil.copytree(REPO/'benchmark/model-comparison-20261004/protocol/nudge-plugin',ROOT/'frozen-plugin',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
with zipfile.ZipFile(REPO/'benchmark/model-comparison-20261004/evidence.zip') as z:
 prompts=[z.read(f'runs/{a}/element-sessions/{a}1/prompt.txt').decode('utf-8') for a in ['A','B']]
 assert prompts[0]==prompts[1]
 prompt=prompts[0]
for arm in ['A','B']:
 study=ROOT/arm; study.mkdir(); workspace=study/'cases/element-sessions';workspace.parent.mkdir()
 subprocess.run(['git','-c','core.longpaths=true','clone','--shared','--no-checkout',str(SOURCE),str(workspace)],check=True,capture_output=True)
 subprocess.run(['git','-c','core.longpaths=true','-c','core.autocrlf=false','checkout','--detach',BASE],cwd=workspace,check=True,capture_output=True)
 assert git('status','--porcelain=v1',cwd=workspace)==b''
 helperdir=study/'public-tools';helperdir.mkdir()
 old=Path(r'D:\masters-nudge-benchmark\round-10-calibration\public-tools\container_check.py').read_text(encoding='utf-8')
 old=old.replace("'--patch','/mnt/d/'+patch.as_posix()[3:]", "'--patch','/mnt/'+patch.drive[0].lower()+patch.as_posix()[2:]")
 (helperdir/'container_check.py').write_text(old,encoding='utf-8')
 previous=r'D:\masters-nudge-benchmark\round-10-calibration\public-tools\container_check.py'
 task=prompt.replace(previous,str(helperdir/'container_check.py'))
 assert task!=prompt
 (study/'prompt.txt').write_text(task,encoding='utf-8')
 home=study/'codex-home';home.mkdir();shutil.copy2(Path.home()/'.codex/auth.json',home/'auth.json')
 data=study/'nudge-data';data.mkdir();save(data/'config.json',{'provider':'openai','model':'gpt-6.1-sol'})
 plan={'arm':arm,'cwd':str(workspace),'prompt_sha256':hashlib.sha256(task.encode()).hexdigest(),'model':'gpt-6.1-sol','reasoning':'medium','provider_model':'gpt-6.1-sol' if arm=='B' else None,'provider_reasoning':'medium' if arm=='B' else None,'actor_timeout_seconds':1800,'source_base':BASE}
 save(study/'plan.json',plan)
save(ROOT/'plan.json',{'purpose':'Fresh one-pair Element rerun with live screen recording, not part of historical rankings','arms':['A','B'],'actor_model':'gpt-6.1-sol','actor_effort':'medium','provider_model':'gpt-6.1-sol','provider_effort':'medium','base_commit':BASE,'cli':str(CLI),'cli_version':subprocess.check_output([str(CLI),'--version']).decode().strip(),'cli_sha256':hashlib.sha256(CLI.read_bytes()).hexdigest(),'differences_from_original':['CLI 0.159.1 instead of original 0.159.0','Isolated repository and public-helper paths; same helper operations','Console recording and passive journal display; no prompt additions'],'retry_policy':'Do not rerun on functional failure, taste, silence, or undesired footage. Preserve both actual results.','source_worktree_before':source_fingerprints,'original_prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'recording_preflight':'Classic console capture visually verified; Windows Terminal GDI capture was black.'})
print(ROOT)