from pathlib import Path
import sys,subprocess,json,time,shutil
ROOT=Path(__file__).resolve().parent;arm=sys.argv[1];run=ROOT/arm
ffmpeg=shutil.which('ffmpeg');title=f'title=MN Live Element {arm}'
args=[ffmpeg,'-hide_banner','-loglevel','info','-f','gdigrab','-framerate','8','-draw_mouse','0','-i',title,'-vf','pad=ceil(iw/2)*2:ceil(ih/2)*2','-c:v','libx264','-preset','ultrafast','-crf','24','-pix_fmt','yuv420p','-y',str(run/'raw-screen.mkv')]
with (run/'capture-stderr.txt').open('w',encoding='utf-8') as log:
 proc=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=log,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
 (run/'recording.json').write_text(json.dumps({'pid':proc.pid,'started_wall':time.time(),'command':args,'window_title':title},indent=2),encoding='utf-8')
 time.sleep(2)
 if proc.poll() is not None:raise RuntimeError('Recorder exited before the Actor started')
 sample=subprocess.run([ffmpeg,'-hide_banner','-loglevel','error','-f','gdigrab','-framerate','1','-i',title,'-frames:v','1','-y',str(run/'first-frame.png')],capture_output=True)
 if sample.returncode:raise RuntimeError(sample.stderr.decode(errors='replace'))
 print('Recording active. Inspect first-frame.png before creating recording-ready.',flush=True)
 while not (run/'actor-done').exists():
  if proc.poll() is not None:raise RuntimeError('Recording failed; preserve original capture and actor')
  time.sleep(.5)
 time.sleep(3)
 proc.stdin.write('q\n');proc.stdin.flush();proc.wait(timeout=20)
 (run/'stop-window').write_text('done',encoding='utf-8')
 (run/'capture-done').write_text('done',encoding='utf-8')
 print('Screen capture finalized.',flush=True)