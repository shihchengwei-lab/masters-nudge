import statistics
import subprocess
import sys
import unittest


class ColdStartTests(unittest.TestCase):
    def test_fresh_process_version_output(self):
        result = subprocess.run(
            [sys.executable, "report_cli.py", "--version"],
            capture_output=True,
            text=True,
            check=True,
        )
        self.assertEqual("report-cli 1.0\n", result.stdout)

    def test_fresh_process_details_output_unchanged(self):
        result = subprocess.run(
            [sys.executable, "report_cli.py", "--details", "alpha"],
            capture_output=True,
            text=True,
            check=True,
        )
        self.assertEqual("alpha:5\n", result.stdout)

    def test_cold_process_version_p95_latency(self):
        import time

        samples = []
        for _ in range(15):
            start = time.perf_counter()
            subprocess.run(
                [sys.executable, "report_cli.py", "--version"],
                capture_output=True,
                text=True,
                check=True,
            )
            samples.append(time.perf_counter() - start)
        samples.sort()
        p95_index = min(len(samples) - 1, int(round(0.95 * (len(samples) - 1))))
        p95 = samples[p95_index]
        self.assertLess(p95, 0.18, f"p95={p95:.3f}s samples={samples}")


if __name__ == "__main__":
    unittest.main()
