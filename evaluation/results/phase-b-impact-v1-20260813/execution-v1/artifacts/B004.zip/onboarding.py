_FULLWIDTH_DIGITS = "０１２３４５６７８９"


def normalize_phone(value):
    cleaned_chars = []
    for char in value:
        if char in (" ", "-"):
            continue
        if char in _FULLWIDTH_DIGITS:
            char = str(_FULLWIDTH_DIGITS.index(char))
        cleaned_chars.append(char)
    cleaned = "".join(cleaned_chars)

    if len(cleaned) != 10 or not cleaned.isascii() or not cleaned.isdigit():
        raise ValueError("phone must contain ten ASCII digits")
    return cleaned
