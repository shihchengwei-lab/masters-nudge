_FULLWIDTH_DIGITS = "０１２３４５６７８９"


def normalize_phone(value):
    cleaned = value.replace(" ", "").replace("-", "")
    cleaned = "".join(
        str(_FULLWIDTH_DIGITS.index(ch)) if ch in _FULLWIDTH_DIGITS else ch
        for ch in cleaned
    )
    if len(cleaned) != 10 or not cleaned.isascii() or not cleaned.isdigit():
        raise ValueError("phone must contain ten ASCII digits")
    return cleaned
