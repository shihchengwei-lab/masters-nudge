import unittest

from onboarding import normalize_phone


class PhoneTests(unittest.TestCase):
    def test_plain_digits_remain_unchanged(self):
        self.assertEqual("0912345678", normalize_phone("0912345678"))

    def test_letters_are_rejected(self):
        with self.assertRaises(ValueError):
            normalize_phone("0912ABC678")

    def test_hyphens_are_stripped(self):
        self.assertEqual("0912345678", normalize_phone("0912-345-678"))

    def test_spaces_are_stripped(self):
        self.assertEqual("0912345678", normalize_phone("0912 345 678"))

    def test_fullwidth_digits_are_normalized(self):
        self.assertEqual("0912345678", normalize_phone("０９１２３４５６７８"))

    def test_wrong_digit_count_is_rejected(self):
        with self.assertRaises(ValueError):
            normalize_phone("091234567")


if __name__ == "__main__":
    unittest.main()
