from decimal import Decimal, ROUND_HALF_UP

from student_policy import student_discount_rate


def quote_total(subtotal, tags):
    percentage = student_discount_rate("student" in tags)
    value = Decimal(str(subtotal)) * (Decimal("1") - percentage)
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
