from decimal import Decimal, ROUND_HALF_UP

from student_policy import student_discount_rate


def checkout_total(subtotal, is_student):
    rate = student_discount_rate(is_student)
    value = Decimal(str(subtotal)) * (Decimal("1") - rate)
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
