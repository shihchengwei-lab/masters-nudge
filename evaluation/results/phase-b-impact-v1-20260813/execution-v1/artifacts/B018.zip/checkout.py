from student_policy import student_discounted_total


def checkout_total(subtotal, is_student):
    return student_discounted_total(subtotal, is_student)
