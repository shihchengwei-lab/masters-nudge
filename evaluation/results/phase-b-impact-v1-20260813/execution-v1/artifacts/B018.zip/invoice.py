from student_policy import student_discounted_total


def invoice_total(subtotal, student_status):
    return student_discounted_total(subtotal, student_status == "student")
