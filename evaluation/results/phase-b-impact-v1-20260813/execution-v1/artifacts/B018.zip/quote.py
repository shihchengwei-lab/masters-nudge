from student_policy import student_discounted_total


def quote_total(subtotal, tags):
    return student_discounted_total(subtotal, "student" in tags)
