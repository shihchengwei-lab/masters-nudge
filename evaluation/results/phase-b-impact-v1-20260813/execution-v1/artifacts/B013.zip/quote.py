from student_policy import apply_student_discount


def quote_total(subtotal, tags):
    return apply_student_discount(subtotal, "student" in tags)
