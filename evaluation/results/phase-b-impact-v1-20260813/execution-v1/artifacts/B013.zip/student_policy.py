from decimal import Decimal, ROUND_HALF_UP

STUDENT_DISCOUNT_RATE = Decimal("0.15")


def apply_student_discount(subtotal, is_student):
    rate = STUDENT_DISCOUNT_RATE if is_student else Decimal("0")
    value = Decimal(str(subtotal)) * (Decimal("1") - rate)
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
