from student_policy import apply_student_discount


def checkout_total(subtotal, is_student):
    return apply_student_discount(subtotal, is_student)
