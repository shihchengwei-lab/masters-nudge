from student_policy import apply_student_discount


def invoice_total(subtotal, student_status):
    return apply_student_discount(subtotal, student_status == "student")
