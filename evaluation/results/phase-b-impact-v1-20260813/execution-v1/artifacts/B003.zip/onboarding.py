import unicodedata


def normalize_phone(value):
    cleaned = unicodedata.normalize("NFKC", value).replace(" ", "").replace("-", "")
    if len(cleaned) != 10 or not cleaned.isascii() or not cleaned.isdigit():
        raise ValueError("phone must contain ten ASCII digits")
    return cleaned
