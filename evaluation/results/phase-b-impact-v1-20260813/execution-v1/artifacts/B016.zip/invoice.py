from decimal import Decimal, ROUND_HALF_UP

from discount import student_discount_rate


def invoice_total(subtotal, student_status):
    discount = student_discount_rate(student_status == "student")
    value = Decimal(str(subtotal)) * (Decimal("1") - discount)
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
