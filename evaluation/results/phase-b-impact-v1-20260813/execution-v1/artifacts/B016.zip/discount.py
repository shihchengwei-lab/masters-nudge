from decimal import Decimal

STUDENT_DISCOUNT_RATE = Decimal("0.15")


def student_discount_rate(is_student):
    return STUDENT_DISCOUNT_RATE if is_student else Decimal("0")
