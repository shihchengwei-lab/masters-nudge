_FULLWIDTH_DIGITS = "０１２３４５６７８９"


def normalize_phone(value):
    cleaned = "".join(ch for ch in value if ch not in " -")
    digits = []
    for ch in cleaned:
        if ch.isdigit() and ch.isascii():
            digits.append(ch)
        elif ch in _FULLWIDTH_DIGITS:
            digits.append(str(_FULLWIDTH_DIGITS.index(ch)))
        else:
            raise ValueError("phone must contain ten ASCII digits")

    normalized = "".join(digits)
    if len(normalized) != 10:
        raise ValueError("phone must contain ten ASCII digits")
    return normalized
