import threading
import time


class SearchController:
    def __init__(self, render, debounce_seconds=0.08):
        self._render = render
        self._debounce_seconds = debounce_seconds
        self._lock = threading.Lock()
        self._latest_id = 0

    def submit(self, query, fetch):
        with self._lock:
            self._latest_id += 1
            request_id = self._latest_id

        def run():
            time.sleep(self._debounce_seconds)
            result = fetch(query)
            with self._lock:
                if request_id == self._latest_id:
                    self._render(query, result)

        thread = threading.Thread(target=run)
        thread.start()
        return thread
