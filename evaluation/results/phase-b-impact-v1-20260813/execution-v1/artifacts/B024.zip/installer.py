import shutil
from pathlib import Path


def install(target_dir):
    target = Path(target_dir)
    target.mkdir(parents=True, exist_ok=True)
    source_dir = Path(__file__).parent
    installed = target / "mn_cli.py"
    shutil.copy2(source_dir / "mn_cli.py", installed)
    shutil.copy2(source_dir / "defaults.json", target / "defaults.json")
    return installed
