import threading


class SearchController:
    def __init__(self, render, debounce_seconds=0.08):
        self._render = render
        self._debounce_seconds = debounce_seconds
        self._lock = threading.Lock()
        self._latest_token = 0

    def submit(self, query, fetch):
        with self._lock:
            self._latest_token += 1
            token = self._latest_token

        def run():
            result = fetch(query)
            with self._lock:
                if token != self._latest_token:
                    return
                self._render(query, result)

        thread = threading.Thread(target=run)
        thread.start()
        return thread
