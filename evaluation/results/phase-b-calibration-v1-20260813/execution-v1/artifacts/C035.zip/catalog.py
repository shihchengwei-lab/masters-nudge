import time


def build_catalog():
    time.sleep(0.22)
    return {"alpha": 5, "beta": 4}


def lookup(name):
    return build_catalog()[name]
