import threading
import time


class RefreshController:
    def __init__(self, render, debounce_seconds=0.08):
        self._render = render
        self._debounce_seconds = debounce_seconds
        self._lock = threading.Lock()
        self._latest_requested = 0
        self._latest_rendered = 0

    def refresh(self, fetch):
        with self._lock:
            self._latest_requested += 1
            request_id = self._latest_requested

        def run():
            time.sleep(self._debounce_seconds)
            result = fetch()
            with self._lock:
                if request_id <= self._latest_rendered:
                    return
                self._latest_rendered = request_id
                self._render(result)

        thread = threading.Thread(target=run)
        thread.start()
        return thread
