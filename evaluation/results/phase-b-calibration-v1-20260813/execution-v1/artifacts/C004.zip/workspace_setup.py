import re


def normalize_workspace_name(value):
    if not value or not value.isascii():
        raise ValueError("workspace name must be an ASCII slug")
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    if not slug:
        raise ValueError("workspace name must be an ASCII slug")
    return slug
