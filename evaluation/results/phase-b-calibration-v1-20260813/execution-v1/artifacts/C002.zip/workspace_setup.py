def normalize_workspace_name(value):
    if not value or not value.isascii():
        raise ValueError("workspace name must be an ASCII slug")
    slug = "-".join(value.strip().lower().split())
    if not slug or any(not (char.islower() or char.isdigit() or char == "-") for char in slug):
        raise ValueError("workspace name must be an ASCII slug")
    return slug
