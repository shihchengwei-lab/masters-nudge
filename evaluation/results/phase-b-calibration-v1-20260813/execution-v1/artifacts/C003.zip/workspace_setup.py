import re


def normalize_workspace_name(value):
    if not value or not value.isascii():
        raise ValueError("workspace name must be an ASCII slug")
    slug = re.sub(r"\s+", "-", value.strip().lower())
    if any(not (char.islower() or char.isdigit() or char == "-") for char in slug):
        raise ValueError("workspace name must be an ASCII slug")
    return slug
