import threading
import time


class RefreshController:
    def __init__(self, render, debounce_seconds=0.08):
        self._render = render
        self._debounce_seconds = debounce_seconds
        self._lock = threading.Lock()
        self._latest_token = 0

    def refresh(self, fetch):
        with self._lock:
            self._latest_token += 1
            token = self._latest_token

        def run():
            time.sleep(self._debounce_seconds)
            result = fetch()
            with self._lock:
                if token != self._latest_token:
                    return
                self._render(result)

        thread = threading.Thread(target=run)
        thread.start()
        return thread
