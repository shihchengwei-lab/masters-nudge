package cache

import (
	"context"
	"crypto/md5"
	"fmt"
)

type contextKey struct{}

var doNotStoreKey contextKey

// WithDoNotStore marks a request to bypass cache reads and writes.
func WithDoNotStore(ctx context.Context) context.Context {
	return context.WithValue(ctx, doNotStoreKey, true)
}

// IsDoNotStore reports whether the request should bypass the cache.
func IsDoNotStore(ctx context.Context) bool {
	marked, _ := ctx.Value(doNotStoreKey).(bool)
	return marked
}

// Cacher modifies and queries a cache
type Cacher interface {
	// Get retrieves a value from the cache, the bool indicates if the item was found
	Get(ctx context.Context, key string) ([]byte, bool, error)
	// Set sets a value in the cache
	Set(ctx context.Context, key string, value []byte) error
	// Delete removes a value from the cache
	Delete(ctx context.Context, key string) error
	fmt.Stringer
}

func Key(k string) string {
	return fmt.Sprintf("flipt:%x", md5.Sum([]byte(k)))
}
