package cache

import (
	"context"
	"crypto/md5"
	"fmt"
)

type contextKey struct{}

// WithDoNotStore marks the context so cached values are neither read nor stored.
func WithDoNotStore(ctx context.Context) context.Context {
	return context.WithValue(ctx, contextKey{}, true)
}

// IsDoNotStore reports whether caching is disabled for this context.
func IsDoNotStore(ctx context.Context) bool {
	doNotStore, _ := ctx.Value(contextKey{}).(bool)
	return doNotStore
}

// Cacher modifies and queries a cache
type Cacher interface {
	// Get retrieves a value from the cache, the bool indicates if the item was found
	Get(ctx context.Context, key string) ([]byte, bool, error)
	// Set sets a value in the cache
	Set(ctx context.Context, key string, value []byte) error
	// Delete removes a value from the cache
	Delete(ctx context.Context, key string) error
	fmt.Stringer
}

func Key(k string) string {
	return fmt.Sprintf("flipt:%x", md5.Sum([]byte(k)))
}
