/*
Copyright 2022 The Matrix.org Foundation C.I.C.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

import React, { useCallback, useContext, useEffect, useRef, useState } from 'react';
import { MatrixClient } from 'matrix-js-sdk/src/client';
import { logger } from 'matrix-js-sdk/src/logger';

import { _t } from "../../../../../languageHandler";
import { DevicesState, useOwnDevices } from '../../devices/useOwnDevices';
import SettingsSubsection from '../../shared/SettingsSubsection';
import { FilteredDeviceList } from '../../devices/FilteredDeviceList';
import CurrentDeviceSection from '../../devices/CurrentDeviceSection';
import SecurityRecommendations from '../../devices/SecurityRecommendations';
import { DeviceSecurityVariation, DeviceWithVerification } from '../../devices/types';
import SettingsTab from '../SettingsTab';
import Modal from '../../../../../Modal';
import SetupEncryptionDialog from '../../../dialogs/security/SetupEncryptionDialog';
import VerificationRequestDialog from '../../../dialogs/VerificationRequestDialog';
import LogoutDialog from '../../../dialogs/LogoutDialog';
import MatrixClientContext from '../../../../../contexts/MatrixClientContext';
import { deleteDevicesWithInteractiveAuth } from '../../devices/deleteDevices';

const useSignOut = (
    matrixClient: MatrixClient,
    refreshDevices: DevicesState['refreshDevices'],
    setSelectedDeviceIds: React.Dispatch<React.SetStateAction<DeviceWithVerification['device_id'][]>>,
): {
        onSignOutCurrentDevice: () => void;
        onSignOutOtherDevices: (deviceIds: DeviceWithVerification['device_id'][]) => Promise<void>;
        signingOutDeviceIds: DeviceWithVerification['device_id'][];
    } => {
    const [signingOutDeviceIds, setSigningOutDeviceIds] = useState<DeviceWithVerification['device_id'][]>([]);

    const onSignOutCurrentDevice = () => {
        Modal.createDialog(
            LogoutDialog,
            {}, // props,
            undefined, // className
            false, // isPriority
            true, // isStatic
        );
    };

    const onSignOutOtherDevices = async (deviceIds: DeviceWithVerification['device_id'][]) => {
        if (!deviceIds.length) {
            return;
        }
        const clearSigningOutDevices = () => {
            setSigningOutDeviceIds(ids => ids.filter(deviceId => !deviceIds.includes(deviceId)));
        };
        try {
            setSigningOutDeviceIds(ids => [...ids, ...deviceIds]);
            await deleteDevicesWithInteractiveAuth(
                matrixClient,
                deviceIds,
                async (success) => {
                    try {
                        if (success) {
                            setSelectedDeviceIds(ids => ids.filter(deviceId => !deviceIds.includes(deviceId)));
                            await refreshDevices();
                        }
                    } catch (error) {
                        logger.error("Error refreshing sessions", error);
                    } finally {
                        clearSigningOutDevices();
                    }
                },
            );
        } catch (error) {
            logger.error("Error deleting sessions", error);
            clearSigningOutDevices();
        }
    };

    return {
        onSignOutCurrentDevice,
        onSignOutOtherDevices,
        signingOutDeviceIds,
    };
};

const SessionManagerTab: React.FC = () => {
    const {
        devices,
        pushers,
        localNotificationSettings,
        currentDeviceId,
        isLoadingDeviceList,
        requestDeviceVerification,
        refreshDevices,
        saveDeviceName,
        setPushNotifications,
        supportsMSC3881,
    } = useOwnDevices();
    const [filter, setFilter] = useState<DeviceSecurityVariation>();
    const [expandedDeviceIds, setExpandedDeviceIds] = useState<DeviceWithVerification['device_id'][]>([]);
    const [selectedDeviceIds, setSelectedDeviceIds] = useState<DeviceWithVerification['device_id'][]>([]);
    const filteredDeviceListRef = useRef<HTMLDivElement>(null);
    const scrollIntoViewTimeoutRef = useRef<ReturnType<typeof setTimeout>>();

    const matrixClient = useContext(MatrixClientContext);
    const userId = matrixClient.getUserId();
    const currentUserMember = userId && matrixClient.getUser(userId) || undefined;

    const onDeviceExpandToggle = (deviceId: DeviceWithVerification['device_id']): void => {
        if (expandedDeviceIds.includes(deviceId)) {
            setExpandedDeviceIds(expandedDeviceIds.filter(id => id !== deviceId));
        } else {
            setExpandedDeviceIds([...expandedDeviceIds, deviceId]);
        }
    };

    const onGoToFilteredList = (filter: DeviceSecurityVariation) => {
        setFilter(filter);
        clearTimeout(scrollIntoViewTimeoutRef.current);
        // wait a tick for the filtered section to rerender with different height
        scrollIntoViewTimeoutRef.current =
            window.setTimeout(() => filteredDeviceListRef.current?.scrollIntoView({
                // align element to top of scrollbox
                block: 'start',
                inline: 'nearest',
                behavior: 'smooth',
            }));
    };

    const { [currentDeviceId]: currentDevice, ...otherDevices } = devices;
    const shouldShowOtherSessions = Object.keys(otherDevices).length > 0;

    const onVerifyCurrentDevice = () => {
        Modal.createDialog(
            SetupEncryptionDialog as unknown as React.ComponentType,
            { onFinished: refreshDevices },
        );
    };

    const onTriggerDeviceVerification = useCallback((deviceId: DeviceWithVerification['device_id']) => {
        if (!requestDeviceVerification) {
            return;
        }
        const verificationRequestPromise = requestDeviceVerification(deviceId);
        Modal.createDialog(VerificationRequestDialog, {
            verificationRequestPromise,
            member: currentUserMember,
            onFinished: async () => {
                const request = await verificationRequestPromise;
                request.cancel();
                await refreshDevices();
            },
        });
    }, [requestDeviceVerification, refreshDevices, currentUserMember]);

    const {
        onSignOutCurrentDevice,
        onSignOutOtherDevices,
        signingOutDeviceIds,
    } = useSignOut(matrixClient, refreshDevices, setSelectedDeviceIds);

    useEffect(() => () => {
        clearTimeout(scrollIntoViewTimeoutRef.current);
    }, [scrollIntoViewTimeoutRef]);

    return <SettingsTab heading={_t('Sessions')}>
        <SecurityRecommendations
            devices={devices}
            goToFilteredList={onGoToFilteredList}
            currentDeviceId={currentDeviceId}
        />
        <CurrentDeviceSection
            device={currentDevice}
            localNotificationSettings={localNotificationSettings.get(currentDeviceId)}
            setPushNotifications={setPushNotifications}
            isSigningOut={signingOutDeviceIds.includes(currentDeviceId)}
            isLoading={isLoadingDeviceList}
            saveDeviceName={(deviceName) => saveDeviceName(currentDeviceId, deviceName)}
            onVerifyCurrentDevice={onVerifyCurrentDevice}
            onSignOutCurrentDevice={onSignOutCurrentDevice}
        />
        {
            shouldShowOtherSessions &&
            <SettingsSubsection
                heading={_t('Other sessions')}
                description={_t(
                    `For best security, verify your sessions and sign out ` +
                    `from any session that you don't recognize or use anymore.`,
                )}
                data-testid='other-sessions-section'
            >
                <FilteredDeviceList
                    devices={otherDevices}
                    pushers={pushers}
                    localNotificationSettings={localNotificationSettings}
                    filter={filter}
                    expandedDeviceIds={expandedDeviceIds}
                    signingOutDeviceIds={signingOutDeviceIds}
                    selectedDeviceIds={selectedDeviceIds}
                    setSelectedDeviceIds={setSelectedDeviceIds}
                    onFilterChange={setFilter}
                    onDeviceExpandToggle={onDeviceExpandToggle}
                    onRequestDeviceVerification={requestDeviceVerification ? onTriggerDeviceVerification : undefined}
                    onSignOutDevices={onSignOutOtherDevices}
                    saveDeviceName={saveDeviceName}
                    setPushNotifications={setPushNotifications}
                    ref={filteredDeviceListRef}
                    supportsMSC3881={supportsMSC3881}
                />
            </SettingsSubsection>
        }
    </SettingsTab>;
};

export default SessionManagerTab;
