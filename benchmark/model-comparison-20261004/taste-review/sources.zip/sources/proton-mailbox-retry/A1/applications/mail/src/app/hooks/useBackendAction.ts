import { useCallback } from 'react';
import { useApi } from '@proton/components';
import { useDispatch } from 'react-redux';
import { backendActionStarted, backendActionFinished } from '../logic/elements/elementsActions';

/** Track item-modifying requests separately from event polling and list queries. */
export const useBackendAction = () => {
    const api = useApi();
    const dispatch = useDispatch();

    return useCallback<typeof api>(
        async <T,>(arg: object): Promise<T> => {
            dispatch(backendActionStarted());
            try {
                return await api<T>(arg);
            } finally {
                dispatch(backendActionFinished());
            }
        },
        [api, dispatch]
    );
};
