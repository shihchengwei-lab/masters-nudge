import { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useApi } from '@proton/components';
import { Api } from '@proton/shared/lib/interfaces';
import { backendActionStarted, backendActionFinished } from '../logic/elements/elementsActions';

/** Count each item-modifying request, including overlapping requests and undo operations. */
export const useApiWithBackendAction = (): Api => {
    const api = useApi();
    const dispatch = useDispatch();

    return useCallback(
        async <T>(request: object): Promise<T> => {
            dispatch(backendActionStarted());
            try {
                return await api<T>(request);
            } finally {
                dispatch(backendActionFinished());
            }
        },
        [api, dispatch]
    );
};
