import { useCallback } from 'react';
import { useApi } from '@proton/components';
import { useDispatch } from 'react-redux';
import { backendActionFinished, backendActionStarted } from '../logic/elements/elementsActions';

export const useBackendAction = () => {
    const api = useApi();
    const dispatch = useDispatch();

    return useCallback(
        async <T>(request: object): Promise<T> => {
            dispatch(backendActionStarted());
            try {
                return await api<T>(request);
            } finally {
                dispatch(backendActionFinished());
            }
        },
        [api, dispatch]
    );
};
