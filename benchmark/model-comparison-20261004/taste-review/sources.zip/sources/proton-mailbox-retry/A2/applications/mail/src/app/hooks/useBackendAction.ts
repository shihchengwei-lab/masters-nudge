import { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useApi } from '@proton/components';
import { backendActionStarted, backendActionFinished } from '../logic/elements/elementsActions';

/** Use for requests that modify mailbox items, including undo requests. */
export const useBackendAction = () => {
    const api = useApi();
    const dispatch = useDispatch();

    return useCallback(
        async <T,>(request: object): Promise<T> => {
            dispatch(backendActionStarted());
            try {
                return await api<T>(request);
            } finally {
                dispatch(backendActionFinished());
            }
        },
        [api, dispatch]
    );
};
