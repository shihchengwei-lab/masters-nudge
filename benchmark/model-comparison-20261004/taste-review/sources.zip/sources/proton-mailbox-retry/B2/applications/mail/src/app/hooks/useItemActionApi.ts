import { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useApi } from '@proton/components';
import { backendActionStarted, backendActionFinished } from '../logic/elements/elementsActions';

/** Track only the lifetime of requests that modify mailbox items. */
export const useItemActionApi = () => {
    const api = useApi();
    const dispatch = useDispatch();

    return useCallback(
        async <T = any>(request: object): Promise<T> => {
            dispatch(backendActionStarted());
            try {
                return await api<T>(request);
            } finally {
                dispatch(backendActionFinished());
            }
        },
        [api, dispatch]
    );
};
