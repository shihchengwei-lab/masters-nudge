import { toMap } from '@proton/shared/lib/helpers/object';
import { Draft } from 'immer';
import { PayloadAction } from '@reduxjs/toolkit';
import isTruthy from '@proton/shared/lib/helpers/isTruthy';
import { diff, range } from '@proton/shared/lib/helpers/array';
import { Message } from '@proton/shared/lib/interfaces/mail/Message';
import { newState } from './elementsSlice';
import {
    ElementsState,
    ESResults,
    EventUpdates,
    NewStateParams,
    OptimisticDelete,
    OptimisticUpdates,
    QueryParams,
    QueryResults,
    RetryData,
} from './elementsTypes';
import { Element } from '../../models/element';
import { isMessage as testIsMessage, parseLabelIDsInEvent } from '../../helpers/elements';
import { newRetry } from './helpers/elementQuery';
import { MAX_ELEMENT_LIST_LOAD_RETRIES, PAGE_SIZE } from '../../constants';

export const globalReset = (state: Draft<ElementsState>) => {
    Object.assign(state, newState());
};

export const reset = (state: Draft<ElementsState>, action: PayloadAction<NewStateParams>) => {
    const waitingRetry = state.retry.dueAt === undefined ? undefined : state.retry;
    Object.assign(state, newState(action.payload), {
        pendingActions: state.pendingActions,
        ...(waitingRetry ? { retry: waitingRetry, pendingRequest: true } : {}),
    });
};

export const updatePage = (state: Draft<ElementsState>, action: PayloadAction<number>) => {
    state.page = action.payload;
};

export const retry = (state: Draft<ElementsState>, action: PayloadAction<RetryData>) => {
    state.invalidated = true;
    state.pendingRequest = false;
    state.pendingRequestID = undefined;
    state.retry = action.payload;
};

export const retryScheduled = (state: Draft<ElementsState>, action: PayloadAction<RetryData>) => {
    state.retry = action.payload;
    state.pendingRequestID = undefined;
};

export const retryStale = (state: Draft<ElementsState>, action: PayloadAction<{ queryParameters: any }>) => {
    state.invalidated = true;
    state.pendingRequest = false;
    state.pendingRequestID = undefined;
    state.retry = newRetry(state.retry, action.payload.queryParameters, undefined);
};

export const backendActionStarted = (state: Draft<ElementsState>) => {
    state.pendingActions += 1;
};

export const backendActionFinished = (state: Draft<ElementsState>) => {
    state.pendingActions = Math.max(0, state.pendingActions - 1);
};

export const loadPending = (
    state: Draft<ElementsState>,
    action: PayloadAction<undefined, string, { arg: QueryParams; requestId: string }>
) => {
    state.pendingRequest = true;
    state.pendingRequestID = action.meta.requestId;
    state.page = action.meta.arg.page;
};

export const loadFulfilled = (
    state: Draft<ElementsState>,
    action: PayloadAction<QueryResults, string, { arg: QueryParams; requestId: string }>
) => {
    // Keep the request blocking further loads until the stale retry delay elapses.
    if (action.payload.Stale === 1) {
        return;
    }
    if (state.pendingRequestID !== action.meta.requestId) {
        return;
    }
    const { page, params } = action.meta.arg;
    const { Total, Elements } = action.payload;

    Object.assign(state, {
        beforeFirstLoad: false,
        invalidated: false,
        pendingRequest: false,
        pendingRequestID: undefined,
        page,
        total: Total,
        retry: newRetry(state.retry, params, undefined),
    });
    state.pages.push(page);
    Object.assign(state.elements, toMap(Elements, 'ID'));
};

export const loadRejected = (
    state: Draft<ElementsState>,
    action: PayloadAction<undefined, string, { condition: boolean }>
) => {
    if (action.meta.condition && state.pendingRequestID === undefined && state.retry.dueAt === undefined) {
        // A local search can reach its API fallback after a modifying operation starts.
        // Retain that fetch as owed so releasing the last operation wakes the normal effect.
        state.pendingRequest = false;
        state.invalidated = true;
    }
};

export const manualPending = (state: Draft<ElementsState>) => {
    state.pendingRequest = true;
};

export const manualFulfilled = (state: Draft<ElementsState>) => {
    state.pendingRequest = false;
};

export const removeExpired = (state: Draft<ElementsState>, action: PayloadAction<Element>) => {
    delete state.elements[action.payload.ID || ''];
};

export const invalidate = (state: Draft<ElementsState>) => {
    state.invalidated = true;
};

export const eventUpdatesPending = (
    state: Draft<ElementsState>,
    action: PayloadAction<undefined, string, { arg: EventUpdates }>
) => {
    const { toCreate, toUpdate, toDelete } = action.meta.arg;
    toCreate.forEach((element) => {
        state.elements[element.ID || ''] = element;
    });
    toUpdate.forEach((element) => {
        const existingElement = state.elements[element.ID || ''];
        if (existingElement) {
            state.elements[element.ID || ''] = parseLabelIDsInEvent(existingElement, element);
        }
    });
    toDelete.forEach((elementID) => {
        delete state.elements[elementID];
    });
};

export const eventUpdatesFulfilled = (
    state: Draft<ElementsState>,
    action: PayloadAction<(Element | undefined)[], string, { arg: EventUpdates }>
) => {
    action.payload.filter(isTruthy).forEach((element) => {
        state.elements[element.ID || ''] = element;
    });
};

export const addESResults = (state: Draft<ElementsState>, action: PayloadAction<ESResults>) => {
    const total = action.payload.elements.length;
    const pages = range(0, Math.ceil(total / PAGE_SIZE));
    // Retry is disabled for encrypted search results, to avoid re-triggering the search several times
    // when there are no results
    Object.assign(state, {
        bypassFilter: [],
        beforeFirstLoad: false,
        invalidated: false,
        pendingRequest: false,
        page: action.payload.page,
        total,
        pages,
        elements: toMap(action.payload.elements, 'ID'),
        retry: { payload: undefined, count: MAX_ELEMENT_LIST_LOAD_RETRIES, error: undefined },
    });
};

export const optimisticUpdates = (state: Draft<ElementsState>, action: PayloadAction<OptimisticUpdates>) => {
    action.payload.elements.forEach((element) => {
        if (element.ID) {
            state.elements[element.ID] = element;
        }
    });
    if (action.payload.isMove) {
        const elementIDs = action.payload.elements.map(({ ID }) => ID || '');
        state.bypassFilter = diff(state.bypassFilter, elementIDs);
    }
    if (action.payload.bypass) {
        const { conversationMode } = action.payload;
        action.payload.elements.forEach((element) => {
            const isMessage = testIsMessage(element);
            const id = (isMessage && conversationMode ? (element as Message).ConversationID : element.ID) || '';
            if (!state.bypassFilter.includes(id)) {
                state.bypassFilter.push(id);
            }
        });
    }
};

export const optimisticDelete = (state: Draft<ElementsState>, action: PayloadAction<OptimisticDelete>) => {
    action.payload.elementIDs.forEach((elementID) => {
        delete state.elements[elementID];
    });
};

export const optimisticEmptyLabel = (state: Draft<ElementsState>) => {
    state.elements = {};
    state.page = 0;
};
