import { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useApi } from '@proton/components';
import { backendActionFinished, backendActionStarted } from '../logic/elements/elementsActions';

export const useBackendAction = () => {
    const api = useApi();
    const dispatch = useDispatch();

    return useCallback(
        async <T = any>(options: object): Promise<T> => {
            dispatch(backendActionStarted());
            try {
                return await api<T>(options);
            } finally {
                dispatch(backendActionFinished());
            }
        },
        [api, dispatch]
    );
};
