import { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useApi } from '@proton/components';
import { backendActionStarted, backendActionFinished } from '../logic/elements/elementsActions';

/** Track each modifying request independently, including overlapping requests and undo. */
export const useElementActionApi = () => {
    const api = useApi();
    const dispatch = useDispatch();

    return useCallback(
        async <T,>(request: Parameters<typeof api>[0]): Promise<T> => {
            dispatch(backendActionStarted());
            try {
                return await api<T>(request);
            } finally {
                dispatch(backendActionFinished());
            }
        },
        [api, dispatch]
    );
};
