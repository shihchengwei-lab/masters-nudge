import { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useApi } from '@proton/components';
import { backendActionFinished, backendActionStarted } from '../logic/elements/elementsActions';

/** Track each modifying request independently, including overlapping and failed requests. */
export const useElementAction = () => {
    const api = useApi();
    const dispatch = useDispatch();

    return useCallback<typeof api>(
        async <T>(request: object): Promise<T> => {
            dispatch(backendActionStarted());
            try {
                return await api<T>(request);
            } finally {
                dispatch(backendActionFinished());
            }
        },
        [api, dispatch]
    );
};
