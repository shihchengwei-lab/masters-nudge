import { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useApi } from '@proton/components';
import { backendActionFinished, backendActionStarted } from '../logic/elements/elementsActions';

/** Keep list refreshes waiting for the actual modifying request, including failures. */
export const useBackendAction = () => {
    const api = useApi();
    const dispatch = useDispatch();

    return useCallback(
        async <T>(request: object): Promise<T> => {
            dispatch(backendActionStarted());
            try {
                return await api<T>(request);
            } finally {
                dispatch(backendActionFinished());
            }
        },
        [api, dispatch]
    );
};
