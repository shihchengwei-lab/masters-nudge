import { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useApi } from '@proton/components';
import { backendActionFinished, backendActionStarted } from '../logic/elements/elementsActions';

/** Track each modifying request separately, including overlapping requests and failures. */
export const useBackendAction = () => {
    const api = useApi();
    const dispatch = useDispatch();

    return useCallback(
        async <T = any>(request: object, optimisticUpdate?: () => void): Promise<T> => {
            dispatch(backendActionStarted());
            try {
                optimisticUpdate?.();
                return await api<T>(request);
            } finally {
                dispatch(backendActionFinished());
            }
        },
        [api, dispatch]
    );
};
