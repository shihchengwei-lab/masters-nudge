'use strict';

const winston = require('winston');
const mime = require('mime');
const path = require('path');
const nconf = require('nconf');
const fs = require('fs').promises;

const db = require('../database');
const file = require('../file');
const image = require('../image');
const meta = require('../meta');
const plugins = require('../plugins');

module.exports = function (User) {
	User.getAllowedProfileImageExtensions = function () {
		const exts = User.getAllowedImageTypes().map(type => mime.getExtension(type));
		if (exts.includes('jpeg')) {
			exts.push('jpg');
		}
		return exts;
	};

	User.getAllowedImageTypes = function () {
		const allowedTypes = ['image/png', 'image/jpeg', 'image/bmp'];
		if (plugins.hooks.hasListeners('filter:image.isFileTypeAllowed')) {
			allowedTypes.push('image/gif');
		}
		return allowedTypes;
	};

	User.updateCoverPosition = async function (uid, position) {
		// Reject anything that isn't two percentages
		if (!/^[\d.]+%\s[\d.]+%$/.test(position)) {
			winston.warn(`[user/updateCoverPosition] Invalid position received: ${position}`);
			throw new Error('[[error:invalid-data]]');
		}

		await User.setUserField(uid, 'cover:position', position);
	};

	User.updateCoverPicture = async function (data) {
		const picture = {
			name: 'profileCover',
			uid: data.uid,
		};

		try {
			if (!data.imageData && data.position) {
				return await User.updateCoverPosition(data.uid, data.position);
			}

			validateUpload(data, meta.config.maximumCoverImageSize, ['image/png', 'image/jpeg', 'image/bmp']);

			picture.path = await image.writeImageDataToTempFile(data.imageData);

			const extension = file.typeToExtension(image.mimeFromBase64(data.imageData));
			const filename = `${data.uid}-profilecover-${Date.now()}${extension}`;
			const uploadData = await image.uploadImage(filename, 'profile', picture);

			await deleteCurrentPicture(data.uid, 'cover:url');
			await User.setUserField(data.uid, 'cover:url', uploadData.url);

			if (data.position) {
				await User.updateCoverPosition(data.uid, data.position);
			}

			return {
				url: uploadData.url,
			};
		} finally {
			await file.delete(picture.path);
		}
	};

	// uploads a image file as profile picture
	User.uploadCroppedPictureFile = async function (data) {
		const userPhoto = data.file;
		if (!meta.config.allowProfileImageUploads) {
			throw new Error('[[error:profile-image-uploads-disabled]]');
		}

		if (userPhoto.size > meta.config.maximumProfileImageSize * 1024) {
			throw new Error(`[[error:file-too-big, ${meta.config.maximumProfileImageSize}]]`);
		}

		if (!userPhoto.type || !User.getAllowedImageTypes().includes(userPhoto.type)) {
			throw new Error('[[error:invalid-image]]');
		}

		const extension = file.typeToExtension(userPhoto.type);
		if (!extension) {
			throw new Error('[[error:invalid-image-extension]]');
		}

		const newPath = await convertToPNG(userPhoto.path);

		await image.resizeImage({
			path: newPath,
			width: meta.config.profileImageDimension,
			height: meta.config.profileImageDimension,
		});

		const filename = generateProfileImageFilename(data.uid, extension);
		const uploadedImage = await image.uploadImage(filename, 'profile', {
			uid: data.uid,
			path: newPath,
			name: 'profileAvatar',
		});

		await deleteCurrentPicture(data.uid, 'uploadedpicture');
		await User.updateProfile(data.callerUid, {
			uid: data.uid,
			uploadedpicture: uploadedImage.url,
			picture: uploadedImage.url,
		}, ['uploadedpicture', 'picture']);
		return uploadedImage;
	};

	// uploads image data in base64 as profile picture
	User.uploadCroppedPicture = async function (data) {
		const picture = {
			name: 'profileAvatar',
			uid: data.uid,
		};

		try {
			if (!meta.config.allowProfileImageUploads) {
				throw new Error('[[error:profile-image-uploads-disabled]]');
			}

			validateUpload(data, meta.config.maximumProfileImageSize, User.getAllowedImageTypes());

			const extension = file.typeToExtension(image.mimeFromBase64(data.imageData));
			if (!extension) {
				throw new Error('[[error:invalid-image-extension]]');
			}

			picture.path = await image.writeImageDataToTempFile(data.imageData);
			picture.path = await convertToPNG(picture.path);

			await image.resizeImage({
				path: picture.path,
				width: meta.config.profileImageDimension,
				height: meta.config.profileImageDimension,
			});

			const filename = generateProfileImageFilename(data.uid, extension);
			const uploadedImage = await image.uploadImage(filename, 'profile', picture);

			await deleteCurrentPicture(data.uid, 'uploadedpicture');
			await User.updateProfile(data.callerUid, {
				uid: data.uid,
				uploadedpicture: uploadedImage.url,
				picture: uploadedImage.url,
			}, ['uploadedpicture', 'picture']);
			return uploadedImage;
		} finally {
			await file.delete(picture.path);
		}
	};

	async function deleteCurrentPicture(uid, field) {
		if (meta.config['profile:keepAllUserImages']) {
			return;
		}
		const value = await User.getUserField(uid, field);
		if (value && value.startsWith('/assets/uploads/profile/')) {
			const filename = value.split('/').pop();
			const uploadPath = path.join(nconf.get('upload_path'), 'profile', filename);
			await file.delete(uploadPath);
		}
	}

	function validateUpload(data, maxSize, allowedTypes) {
		if (!data.imageData) {
			throw new Error('[[error:invalid-data]]');
		}
		const size = image.sizeFromBase64(data.imageData);
		if (size > maxSize * 1024) {
			throw new Error(`[[error:file-too-big, ${maxSize}]]`);
		}

		const type = image.mimeFromBase64(data.imageData);
		if (!type || !allowedTypes.includes(type)) {
			throw new Error('[[error:invalid-image]]');
		}
	}

	async function convertToPNG(path) {
		const convertToPNG = meta.config['profile:convertProfileImageToPNG'] === 1;
		if (!convertToPNG) {
			return path;
		}
		const newPath = await image.normalise(path);
		await file.delete(path);
		return newPath;
	}

	function generateProfileImageFilename(uid, extension) {
		const convertToPNG = meta.config['profile:convertProfileImageToPNG'] === 1;
		return `${uid}-profileavatar-${Date.now()}${convertToPNG ? '.png' : extension}`;
	}

	User.getLocalCoverPath = async uid => await getLocalPicturePath(uid, 'cover:url', 'cover');
	User.getLocalAvatarPath = async uid => await getLocalPicturePath(uid, 'uploadedpicture', 'avatar');

	async function getLocalPicturePath(uid, field, type) {
		const value = await db.getObjectField(`user:${uid}`, field);
		if (!value) {
			return false;
		}
		const prefixes = ['/assets/uploads/', `${nconf.get('relative_path') || ''}/assets/uploads/`];
		const prefix = prefixes.find(prefix => value.startsWith(prefix));
		if (!prefix) {
			return false;
		}
		const relative = value.slice(prefix.length);
		if (!/^(profile|files)\/[^/\\]+$/.test(relative)) {
			return false;
		}
		const localPath = path.join(nconf.get('upload_path'), relative);
		if (await file.exists(localPath)) {
			return localPath;
		}
		const paths = await getProfileImagePaths(uid, type);
		return paths[0] || false;
	}

	async function getProfileImagePaths(uid, type) {
		if (!/^[1-9]\d*$/.test(String(uid))) {
			throw new Error('[[error:invalid-uid]]');
		}
		const folder = path.join(nconf.get('upload_path'), 'profile');
		let names;
		try {
			names = await fs.readdir(folder);
		} catch (err) {
			if (err.code === 'ENOENT') {
				return [];
			}
			throw err;
		}
		const pattern = profileImagePattern(uid, type);
		return names.filter(name => pattern.test(name)).map(name => path.join(folder, name));
	}

	function profileImagePattern(uid, type) {
		const extensions = User.getAllowedProfileImageExtensions().join('|');
		return new RegExp(`^${uid}-profile${type}(?:-\\d+)?\\.(${extensions})$`, 'i');
	}

	async function removePictureFiles(uid, type, getLocalPath) {
		const paths = await getProfileImagePaths(uid, type);
		const currentPath = await getLocalPath(uid);
		if (currentPath && profileImagePattern(uid, type).test(path.basename(currentPath))) {
			paths.push(currentPath);
		} else if (currentPath && path.dirname(currentPath) === path.join(nconf.get('upload_path'), 'files')) {
			// Upload ownership is recorded separately from the image URL.
			const uploadName = `files/${path.basename(currentPath)}`;
			const otherPath = await (type === 'avatar' ? User.getLocalCoverPath(uid) : User.getLocalAvatarPath(uid));
			const isProfileImage = /^\d+-profile(cover|avatar)(?:-\d+)?\./i.test(path.basename(currentPath));
			if (!isProfileImage && currentPath !== otherPath &&
				await db.isSortedSetMember(`uid:${uid}:uploads`, uploadName)) {
				paths.push(currentPath);
			}
		}
		await Promise.all([...new Set(paths)].map(async (imagePath) => {
			try {
				await fs.unlink(imagePath);
			} catch (err) {
				if (err.code !== 'ENOENT') {
					throw err;
				}
			}
		}));
	}

	User.removeCoverPicture = async function (uid) {
		await removePictureFiles(uid, 'cover', User.getLocalCoverPath);
		await db.deleteObjectFields(`user:${uid}`, ['cover:url', 'cover:position']);
	};

	User.removeProfileImage = async function (uid) {
		const userData = await User.getUserFields(uid, ['uploadedpicture', 'picture']);
		await removePictureFiles(uid, 'avatar', User.getLocalAvatarPath);
		await User.setUserFields(uid, {
			uploadedpicture: '',
			picture: userData.uploadedpicture === userData.picture ? '' : userData.picture,
		});
		return userData;
	};
};
