'use strict';

const winston = require('winston');
const mime = require('mime');
const path = require('path');
const nconf = require('nconf');
const fs = require('fs').promises;

const db = require('../database');
const file = require('../file');
const image = require('../image');
const meta = require('../meta');
const plugins = require('../plugins');

module.exports = function (User) {
	User.getAllowedProfileImageExtensions = function () {
		const exts = User.getAllowedImageTypes().map(type => mime.getExtension(type));
		if (exts.includes('jpeg')) {
			exts.push('jpg');
		}
		return exts;
	};

	User.getAllowedImageTypes = function () {
		const allowedTypes = ['image/png', 'image/jpeg', 'image/bmp'];
		if (plugins.hooks.hasListeners('filter:image.isFileTypeAllowed')) {
			allowedTypes.push('image/gif');
		}
		return allowedTypes;
	};

	User.updateCoverPosition = async function (uid, position) {
		// Reject anything that isn't two percentages
		if (!/^[\d.]+%\s[\d.]+%$/.test(position)) {
			winston.warn(`[user/updateCoverPosition] Invalid position received: ${position}`);
			throw new Error('[[error:invalid-data]]');
		}

		await User.setUserField(uid, 'cover:position', position);
	};

	User.updateCoverPicture = async function (data) {
		const picture = {
			name: 'profileCover',
			uid: data.uid,
		};

		try {
			if (!data.imageData && data.position) {
				return await User.updateCoverPosition(data.uid, data.position);
			}

			validateUpload(data, meta.config.maximumCoverImageSize, ['image/png', 'image/jpeg', 'image/bmp']);

			picture.path = await image.writeImageDataToTempFile(data.imageData);

			const extension = file.typeToExtension(image.mimeFromBase64(data.imageData));
			const filename = `${data.uid}-profilecover-${Date.now()}${extension}`;
			const uploadData = await image.uploadImage(filename, 'profile', picture);

			await deleteCurrentPicture(data.uid, 'cover:url');
			await User.setUserField(data.uid, 'cover:url', uploadData.url);

			if (data.position) {
				await User.updateCoverPosition(data.uid, data.position);
			}

			return {
				url: uploadData.url,
			};
		} finally {
			await file.delete(picture.path);
		}
	};

	// uploads a image file as profile picture
	User.uploadCroppedPictureFile = async function (data) {
		const userPhoto = data.file;
		if (!meta.config.allowProfileImageUploads) {
			throw new Error('[[error:profile-image-uploads-disabled]]');
		}

		if (userPhoto.size > meta.config.maximumProfileImageSize * 1024) {
			throw new Error(`[[error:file-too-big, ${meta.config.maximumProfileImageSize}]]`);
		}

		if (!userPhoto.type || !User.getAllowedImageTypes().includes(userPhoto.type)) {
			throw new Error('[[error:invalid-image]]');
		}

		const extension = file.typeToExtension(userPhoto.type);
		if (!extension) {
			throw new Error('[[error:invalid-image-extension]]');
		}

		const newPath = await convertToPNG(userPhoto.path);

		await image.resizeImage({
			path: newPath,
			width: meta.config.profileImageDimension,
			height: meta.config.profileImageDimension,
		});

		const filename = generateProfileImageFilename(data.uid, extension);
		const uploadedImage = await image.uploadImage(filename, 'profile', {
			uid: data.uid,
			path: newPath,
			name: 'profileAvatar',
		});

		await deleteCurrentPicture(data.uid, 'uploadedpicture');
		await User.updateProfile(data.callerUid, {
			uid: data.uid,
			uploadedpicture: uploadedImage.url,
			picture: uploadedImage.url,
		}, ['uploadedpicture', 'picture']);
		return uploadedImage;
	};

	// uploads image data in base64 as profile picture
	User.uploadCroppedPicture = async function (data) {
		const picture = {
			name: 'profileAvatar',
			uid: data.uid,
		};

		try {
			if (!meta.config.allowProfileImageUploads) {
				throw new Error('[[error:profile-image-uploads-disabled]]');
			}

			validateUpload(data, meta.config.maximumProfileImageSize, User.getAllowedImageTypes());

			const extension = file.typeToExtension(image.mimeFromBase64(data.imageData));
			if (!extension) {
				throw new Error('[[error:invalid-image-extension]]');
			}

			picture.path = await image.writeImageDataToTempFile(data.imageData);
			picture.path = await convertToPNG(picture.path);

			await image.resizeImage({
				path: picture.path,
				width: meta.config.profileImageDimension,
				height: meta.config.profileImageDimension,
			});

			const filename = generateProfileImageFilename(data.uid, extension);
			const uploadedImage = await image.uploadImage(filename, 'profile', picture);

			await deleteCurrentPicture(data.uid, 'uploadedpicture');
			await User.updateProfile(data.callerUid, {
				uid: data.uid,
				uploadedpicture: uploadedImage.url,
				picture: uploadedImage.url,
			}, ['uploadedpicture', 'picture']);
			return uploadedImage;
		} finally {
			await file.delete(picture.path);
		}
	};

	async function deleteCurrentPicture(uid, field) {
		if (meta.config['profile:keepAllUserImages']) {
			return;
		}
		const localPath = await getLocalImagePath(uid, field);
		if (localPath) {
			await file.delete(localPath);
		}
	}

	User.getLocalCoverPath = async function (uid) {
		return await getLocalImagePath(uid, 'cover:url');
	};

	User.getLocalAvatarPath = async function (uid) {
		return await getLocalImagePath(uid, 'uploadedpicture');
	};

	async function getLocalImagePath(uid, field) {
		const url = await db.getObjectField(`user:${uid}`, field);
		const localPath = file.getLocalUploadPath(url);
		const candidate = localPath && getProfileImage(localPath);
		const type = field === 'cover:url' ? 'cover' : 'avatar';
		return candidate && candidate.owner === String(uid) && candidate.type === type &&
			await file.exists(localPath) ? localPath : false;
	}

	function getProfileImage(localPath) {
		const match = path.basename(localPath).match(/^(\d+)-profile(cover|avatar)(?:-\d+)?\.([^.]+)$/);
		if (!match || !User.getAllowedProfileImageExtensions().includes(match[3].toLowerCase())) {
			return false;
		}
		return { owner: match[1], type: match[2], path: localPath };
	}

	async function removeImageFiles(uid, type, localPath) {
		const folders = new Set([
			path.join(nconf.get('upload_path'), 'profile'),
			path.join(nconf.get('upload_path'), 'files'),
		]);
		if (localPath) {
			folders.add(path.dirname(localPath));
		}
		const candidates = await Promise.all(Array.from(folders, async (folder) => {
			try {
				const filenames = await fs.readdir(folder);
				return filenames.map(filename => getProfileImage(path.join(folder, filename)));
			} catch (err) {
				if (err.code !== 'ENOENT') {
					throw err;
				}
				return [];
			}
		}));
		await Promise.all(candidates.flat()
			.filter(candidate => candidate && candidate.owner === String(uid) && candidate.type === type)
			.map(candidate => file.delete(candidate.path)));
	}

	function validateUpload(data, maxSize, allowedTypes) {
		if (!data.imageData) {
			throw new Error('[[error:invalid-data]]');
		}
		const size = image.sizeFromBase64(data.imageData);
		if (size > maxSize * 1024) {
			throw new Error(`[[error:file-too-big, ${maxSize}]]`);
		}

		const type = image.mimeFromBase64(data.imageData);
		if (!type || !allowedTypes.includes(type)) {
			throw new Error('[[error:invalid-image]]');
		}
	}

	async function convertToPNG(path) {
		const convertToPNG = meta.config['profile:convertProfileImageToPNG'] === 1;
		if (!convertToPNG) {
			return path;
		}
		const newPath = await image.normalise(path);
		await file.delete(path);
		return newPath;
	}

	function generateProfileImageFilename(uid, extension) {
		const convertToPNG = meta.config['profile:convertProfileImageToPNG'] === 1;
		return `${uid}-profileavatar-${Date.now()}${convertToPNG ? '.png' : extension}`;
	}

	User.removeCoverPicture = async function (uid) {
		await removeImageFiles(uid, 'cover', await User.getLocalCoverPath(uid));
		await db.deleteObjectFields(`user:${uid}`, ['cover:url', 'cover:position']);
	};

	User.removeProfileImage = async function (uid) {
		const userData = await User.getUserFields(uid, ['uploadedpicture', 'picture']);
		await removeImageFiles(uid, 'avatar', await User.getLocalAvatarPath(uid));
		await User.setUserFields(uid, {
			uploadedpicture: '',
			// Reset the selected picture only if it was the uploaded avatar.
			picture: userData.uploadedpicture === userData.picture ? '' : userData.picture,
		});
		return userData;
	};
};
