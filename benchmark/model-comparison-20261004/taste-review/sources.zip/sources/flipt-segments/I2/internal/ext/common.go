package ext

import (
	"fmt"

	"go.flipt.io/flipt/rpc/flipt"
)

type Document struct {
	Version   string     `yaml:"version,omitempty"`
	Namespace string     `yaml:"namespace,omitempty"`
	Flags     []*Flag    `yaml:"flags,omitempty"`
	Segments  []*Segment `yaml:"segments,omitempty"`
}

type Flag struct {
	Key         string     `yaml:"key,omitempty"`
	Name        string     `yaml:"name,omitempty"`
	Type        string     `yaml:"type,omitempty"`
	Description string     `yaml:"description,omitempty"`
	Enabled     bool       `yaml:"enabled"`
	Variants    []*Variant `yaml:"variants,omitempty"`
	Rules       []*Rule    `yaml:"rules,omitempty"`
	Rollouts    []*Rollout `yaml:"rollouts,omitempty"`
}

type Variant struct {
	Key         string      `yaml:"key,omitempty"`
	Name        string      `yaml:"name,omitempty"`
	Description string      `yaml:"description,omitempty"`
	Attachment  interface{} `yaml:"attachment,omitempty"`
}

type Rule struct {
	SegmentKey      string          `yaml:"segment,omitempty"`
	Rank            uint            `yaml:"rank,omitempty"`
	SegmentKeys     []string        `yaml:"segments,omitempty"`
	SegmentOperator string          `yaml:"operator,omitempty"`
	Distributions   []*Distribution `yaml:"distributions,omitempty"`
}

// ruleYAML keeps legacy rule fields readable while exporting a unified segment.
type ruleYAML struct {
	Segment         ruleSegment     `yaml:"segment,omitempty"`
	Rank            uint            `yaml:"rank,omitempty"`
	SegmentKeys     []string        `yaml:"segments,omitempty"`
	SegmentOperator string          `yaml:"operator,omitempty"`
	Distributions   []*Distribution `yaml:"distributions,omitempty"`
}

type ruleSegment struct {
	Key      string   `yaml:"-"`
	Keys     []string `yaml:"keys"`
	Operator string   `yaml:"operator"`
}

func (s ruleSegment) MarshalYAML() (interface{}, error) {
	if s.Key != "" {
		return s.Key, nil
	}
	if len(s.Keys) == 1 {
		return s.Keys[0], nil
	}
	if s.Operator == "" {
		s.Operator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
	}
	type segmentObject ruleSegment
	return segmentObject(s), nil
}

func (s *ruleSegment) UnmarshalYAML(unmarshal func(interface{}) error) error {
	var key string
	if err := unmarshal(&key); err == nil {
		*s = ruleSegment{Key: key}
		return nil
	}
	type segmentObject ruleSegment
	var object segmentObject
	if err := unmarshal(&object); err != nil {
		return err
	}
	*s = ruleSegment(object)
	return nil
}

func (r Rule) MarshalYAML() (interface{}, error) {
	return ruleYAML{
		Segment: ruleSegment{
			Key:      r.SegmentKey,
			Keys:     r.SegmentKeys,
			Operator: r.SegmentOperator,
		},
		Rank:          r.Rank,
		Distributions: r.Distributions,
	}, nil
}

func (r *Rule) UnmarshalYAML(unmarshal func(interface{}) error) error {
	var decoded ruleYAML
	if err := unmarshal(&decoded); err != nil {
		return err
	}
	keys, operator := decoded.SegmentKeys, decoded.SegmentOperator
	if decoded.Segment.Keys != nil {
		if len(keys) > 0 {
			return fmt.Errorf("rule cannot have both segment.keys and segments")
		}
		keys, operator = decoded.Segment.Keys, decoded.Segment.Operator
	}
	if decoded.Segment.Key != "" || len(keys) == 1 || operator == "" {
		operator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
	}
	*r = Rule{
		SegmentKey:      decoded.Segment.Key,
		SegmentKeys:     keys,
		SegmentOperator: operator,
		Rank:            decoded.Rank,
		Distributions:   decoded.Distributions,
	}
	return nil
}

type Distribution struct {
	VariantKey string  `yaml:"variant,omitempty"`
	Rollout    float32 `yaml:"rollout,omitempty"`
}

type Rollout struct {
	Description string         `yaml:"description,omitempty"`
	Segment     *SegmentRule   `yaml:"segment,omitempty"`
	Threshold   *ThresholdRule `yaml:"threshold,omitempty"`
}

type SegmentRule struct {
	Key      string   `yaml:"key,omitempty"`
	Keys     []string `yaml:"keys,omitempty"`
	Operator string   `yaml:"operator,omitempty"`
	Value    bool     `yaml:"value,omitempty"`
}

type ThresholdRule struct {
	Percentage float32 `yaml:"percentage,omitempty"`
	Value      bool    `yaml:"value,omitempty"`
}

type Segment struct {
	Key         string        `yaml:"key,omitempty"`
	Name        string        `yaml:"name,omitempty"`
	Description string        `yaml:"description,omitempty"`
	Constraints []*Constraint `yaml:"constraints,omitempty"`
	MatchType   string        `yaml:"match_type,omitempty"`
}

type Constraint struct {
	Type        string `yaml:"type,omitempty"`
	Property    string `yaml:"property,omitempty"`
	Operator    string `yaml:"operator,omitempty"`
	Value       string `yaml:"value,omitempty"`
	Description string `yaml:"description,omitempty"`
}
