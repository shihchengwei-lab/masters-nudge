package ext

import (
	"fmt"

	"go.flipt.io/flipt/rpc/flipt"
)

type Document struct {
	Version   string     `yaml:"version,omitempty"`
	Namespace string     `yaml:"namespace,omitempty"`
	Flags     []*Flag    `yaml:"flags,omitempty"`
	Segments  []*Segment `yaml:"segments,omitempty"`
}

type Flag struct {
	Key         string     `yaml:"key,omitempty"`
	Name        string     `yaml:"name,omitempty"`
	Type        string     `yaml:"type,omitempty"`
	Description string     `yaml:"description,omitempty"`
	Enabled     bool       `yaml:"enabled"`
	Variants    []*Variant `yaml:"variants,omitempty"`
	Rules       []*Rule    `yaml:"rules,omitempty"`
	Rollouts    []*Rollout `yaml:"rollouts,omitempty"`
}

type Variant struct {
	Key         string      `yaml:"key,omitempty"`
	Name        string      `yaml:"name,omitempty"`
	Description string      `yaml:"description,omitempty"`
	Attachment  interface{} `yaml:"attachment,omitempty"`
}

type Rule struct {
	SegmentKey      string          `yaml:"segment,omitempty"`
	Rank            uint            `yaml:"rank,omitempty"`
	SegmentKeys     []string        `yaml:"segments,omitempty"`
	SegmentOperator string          `yaml:"operator,omitempty"`
	Distributions   []*Distribution `yaml:"distributions,omitempty"`
}

// MarshalYAML keeps single-segment rules compact and groups multiple segment
// keys with their operator under the same field.
func (r Rule) MarshalYAML() (interface{}, error) {
	keys := r.SegmentKeys
	if len(keys) == 0 && r.SegmentKey != "" {
		keys = []string{r.SegmentKey}
	}
	var segment interface{}
	switch {
	case len(keys) == 1:
		segment = keys[0]
	case len(keys) > 1:
		operator := r.SegmentOperator
		if operator == "" {
			operator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
		}
		segment = struct {
			Keys     []string `yaml:"keys"`
			Operator string   `yaml:"operator"`
		}{keys, operator}
	}

	return struct {
		Segment       interface{}     `yaml:"segment,omitempty"`
		Rank          uint            `yaml:"rank,omitempty"`
		Distributions []*Distribution `yaml:"distributions,omitempty"`
	}{segment, r.Rank, r.Distributions}, nil
}

// UnmarshalYAML accepts both segment formats, as well as the older separate
// segments and operator fields for existing configurations.
func (r *Rule) UnmarshalYAML(unmarshal func(interface{}) error) error {
	var value struct {
		Segment       *ruleSegment    `yaml:"segment"`
		Rank          uint            `yaml:"rank"`
		SegmentKeys   []string        `yaml:"segments"`
		Operator      string          `yaml:"operator"`
		Distributions []*Distribution `yaml:"distributions"`
	}
	if err := unmarshal(&value); err != nil {
		return err
	}
	if value.Segment != nil && len(value.SegmentKeys) > 0 {
		return fmt.Errorf("rule cannot have both segment and segments")
	}

	*r = Rule{
		SegmentKeys:     value.SegmentKeys,
		SegmentOperator: value.Operator,
		Rank:            value.Rank,
		Distributions:   value.Distributions,
	}
	if value.Segment != nil {
		r.SegmentKey = value.Segment.Key
		if value.Segment.Keys != nil {
			r.SegmentKeys = value.Segment.Keys
			r.SegmentOperator = value.Segment.Operator
		}
	}
	return nil
}

type ruleSegment struct {
	Key      string   `yaml:"-"`
	Keys     []string `yaml:"keys"`
	Operator string   `yaml:"operator"`
}

func (s *ruleSegment) UnmarshalYAML(unmarshal func(interface{}) error) error {
	var key string
	if err := unmarshal(&key); err == nil {
		*s = ruleSegment{Key: key}
		return nil
	}

	// Use an alias so decoding the object does not call this method again.
	type segment ruleSegment
	var value segment
	if err := unmarshal(&value); err != nil {
		return err
	}
	*s = ruleSegment(value)
	return nil
}

type Distribution struct {
	VariantKey string  `yaml:"variant,omitempty"`
	Rollout    float32 `yaml:"rollout,omitempty"`
}

type Rollout struct {
	Description string         `yaml:"description,omitempty"`
	Segment     *SegmentRule   `yaml:"segment,omitempty"`
	Threshold   *ThresholdRule `yaml:"threshold,omitempty"`
}

type SegmentRule struct {
	Key      string   `yaml:"key,omitempty"`
	Keys     []string `yaml:"keys,omitempty"`
	Operator string   `yaml:"operator,omitempty"`
	Value    bool     `yaml:"value,omitempty"`
}

type ThresholdRule struct {
	Percentage float32 `yaml:"percentage,omitempty"`
	Value      bool    `yaml:"value,omitempty"`
}

type Segment struct {
	Key         string        `yaml:"key,omitempty"`
	Name        string        `yaml:"name,omitempty"`
	Description string        `yaml:"description,omitempty"`
	Constraints []*Constraint `yaml:"constraints,omitempty"`
	MatchType   string        `yaml:"match_type,omitempty"`
}

type Constraint struct {
	Type        string `yaml:"type,omitempty"`
	Property    string `yaml:"property,omitempty"`
	Operator    string `yaml:"operator,omitempty"`
	Value       string `yaml:"value,omitempty"`
	Description string `yaml:"description,omitempty"`
}
