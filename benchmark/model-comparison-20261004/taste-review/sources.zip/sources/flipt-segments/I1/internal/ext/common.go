package ext

import (
	"fmt"

	"go.flipt.io/flipt/rpc/flipt"
)

type Document struct {
	Version   string     `yaml:"version,omitempty"`
	Namespace string     `yaml:"namespace,omitempty"`
	Flags     []*Flag    `yaml:"flags,omitempty"`
	Segments  []*Segment `yaml:"segments,omitempty"`
}

type Flag struct {
	Key         string     `yaml:"key,omitempty"`
	Name        string     `yaml:"name,omitempty"`
	Type        string     `yaml:"type,omitempty"`
	Description string     `yaml:"description,omitempty"`
	Enabled     bool       `yaml:"enabled"`
	Variants    []*Variant `yaml:"variants,omitempty"`
	Rules       []*Rule    `yaml:"rules,omitempty"`
	Rollouts    []*Rollout `yaml:"rollouts,omitempty"`
}

type Variant struct {
	Key         string      `yaml:"key,omitempty"`
	Name        string      `yaml:"name,omitempty"`
	Description string      `yaml:"description,omitempty"`
	Attachment  interface{} `yaml:"attachment,omitempty"`
}

type Rule struct {
	Segment       RuleSegment     `yaml:"segment,omitempty"`
	Rank          uint            `yaml:"rank,omitempty"`
	Distributions []*Distribution `yaml:"distributions,omitempty"`
}

// RuleSegment keeps both YAML representations in a single internal form.
type RuleSegment struct {
	Keys     []string `yaml:"keys"`
	Operator string   `yaml:"operator"`
}

func (s *RuleSegment) normalizeOperator() {
	if len(s.Keys) == 1 || s.Operator == "" {
		s.Operator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
	}
}

func (s RuleSegment) MarshalYAML() (interface{}, error) {
	if len(s.Keys) == 1 {
		return s.Keys[0], nil
	}

	s.normalizeOperator()
	type plain RuleSegment
	return plain(s), nil
}

func (s *RuleSegment) UnmarshalYAML(unmarshal func(interface{}) error) error {
	var value interface{}
	if err := unmarshal(&value); err != nil {
		return err
	}

	var segment RuleSegment
	switch value := value.(type) {
	case string:
		segment.Keys = []string{value}
	case map[interface{}]interface{}, map[string]interface{}:
		type plain RuleSegment
		if err := unmarshal((*plain)(&segment)); err != nil {
			return err
		}
	default:
		return fmt.Errorf("rule segment must be a string or an object with keys and operator")
	}

	segment.normalizeOperator()
	*s = segment
	return nil
}

// UnmarshalYAML also accepts the previous segments/operator fields on import.
func (r *Rule) UnmarshalYAML(unmarshal func(interface{}) error) error {
	type plain Rule
	var legacy struct {
		Rule     plain    `yaml:",inline"`
		Keys     []string `yaml:"segments"`
		Operator string   `yaml:"operator"`
	}
	if err := unmarshal(&legacy); err != nil {
		return err
	}

	if len(legacy.Keys) > 0 {
		if len(legacy.Rule.Segment.Keys) > 0 {
			return fmt.Errorf("rule cannot have both segment and segments")
		}
		legacy.Rule.Segment = RuleSegment{Keys: legacy.Keys, Operator: legacy.Operator}
		legacy.Rule.Segment.normalizeOperator()
	}

	*r = Rule(legacy.Rule)
	return nil
}

type Distribution struct {
	VariantKey string  `yaml:"variant,omitempty"`
	Rollout    float32 `yaml:"rollout,omitempty"`
}

type Rollout struct {
	Description string         `yaml:"description,omitempty"`
	Segment     *SegmentRule   `yaml:"segment,omitempty"`
	Threshold   *ThresholdRule `yaml:"threshold,omitempty"`
}

type SegmentRule struct {
	Key   string `yaml:"key,omitempty"`
	Value bool   `yaml:"value,omitempty"`
}

type ThresholdRule struct {
	Percentage float32 `yaml:"percentage,omitempty"`
	Value      bool    `yaml:"value,omitempty"`
}

type Segment struct {
	Key         string        `yaml:"key,omitempty"`
	Name        string        `yaml:"name,omitempty"`
	Description string        `yaml:"description,omitempty"`
	Constraints []*Constraint `yaml:"constraints,omitempty"`
	MatchType   string        `yaml:"match_type,omitempty"`
}

type Constraint struct {
	Type        string `yaml:"type,omitempty"`
	Property    string `yaml:"property,omitempty"`
	Operator    string `yaml:"operator,omitempty"`
	Value       string `yaml:"value,omitempty"`
	Description string `yaml:"description,omitempty"`
}
