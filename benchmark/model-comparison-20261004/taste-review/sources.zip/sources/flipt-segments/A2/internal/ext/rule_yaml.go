package ext

import "go.flipt.io/flipt/rpc/flipt"

// ruleSegment is the YAML string or object representation of a rule target.
// Rollout targets use SegmentRule and retain their existing YAML shape.
type ruleSegment struct {
	Key      string   `yaml:"-"`
	Keys     []string `yaml:"keys"`
	Operator string   `yaml:"operator"`
}

func (s *ruleSegment) UnmarshalYAML(unmarshal func(interface{}) error) error {
	var key string
	if err := unmarshal(&key); err == nil {
		*s = ruleSegment{Key: key}
		return nil
	}
	type plain ruleSegment
	var target plain
	if err := unmarshal(&target); err != nil {
		return err
	}
	*s = ruleSegment(target)
	return nil
}

func (r Rule) MarshalYAML() (interface{}, error) {
	type plain Rule
	var segment interface{}
	if r.SegmentKey != "" {
		segment = r.SegmentKey
	} else if len(r.SegmentKeys) == 1 {
		segment = r.SegmentKeys[0]
	} else if len(r.SegmentKeys) > 1 {
		operator := r.SegmentOperator
		if operator == "" {
			operator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
		}
		segment = ruleSegment{Keys: r.SegmentKeys, Operator: operator}
	}
	r.SegmentKeys = nil
	r.SegmentOperator = ""
	return struct {
		plain               `yaml:",inline"`
		Segment interface{} `yaml:"segment,omitempty"`
	}{plain: plain(r), Segment: segment}, nil
}

func (r *Rule) UnmarshalYAML(unmarshal func(interface{}) error) error {
	type plain Rule
	var wire struct {
		plain                `yaml:",inline"`
		Segment *ruleSegment `yaml:"segment,omitempty"`
	}
	if err := unmarshal(&wire); err != nil {
		return err
	}
	*r = Rule(wire.plain)
	if wire.Segment != nil {
		r.SegmentKey = wire.Segment.Key
		if wire.Segment.Key == "" {
			r.SegmentKeys = wire.Segment.Keys
			r.SegmentOperator = wire.Segment.Operator
		}
	}
	if r.SegmentKey != "" || len(r.SegmentKeys) == 1 {
		r.SegmentOperator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
	}
	return nil
}
