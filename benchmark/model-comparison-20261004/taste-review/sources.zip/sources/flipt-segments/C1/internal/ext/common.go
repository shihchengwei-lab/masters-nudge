package ext

import "go.flipt.io/flipt/rpc/flipt"

type Document struct {
	Version   string     `yaml:"version,omitempty"`
	Namespace string     `yaml:"namespace,omitempty"`
	Flags     []*Flag    `yaml:"flags,omitempty"`
	Segments  []*Segment `yaml:"segments,omitempty"`
}

type Flag struct {
	Key         string     `yaml:"key,omitempty"`
	Name        string     `yaml:"name,omitempty"`
	Type        string     `yaml:"type,omitempty"`
	Description string     `yaml:"description,omitempty"`
	Enabled     bool       `yaml:"enabled"`
	Variants    []*Variant `yaml:"variants,omitempty"`
	Rules       []*Rule    `yaml:"rules,omitempty"`
	Rollouts    []*Rollout `yaml:"rollouts,omitempty"`
}

type Variant struct {
	Key         string      `yaml:"key,omitempty"`
	Name        string      `yaml:"name,omitempty"`
	Description string      `yaml:"description,omitempty"`
	Attachment  interface{} `yaml:"attachment,omitempty"`
}

type Rule struct {
	Segment       *RuleSegment    `yaml:"segment,omitempty"`
	Rank          uint            `yaml:"rank,omitempty"`
	Distributions []*Distribution `yaml:"distributions,omitempty"`
}

// RuleSegment represents either a single segment key or a group of segment keys.
type RuleSegment struct {
	Key      string   `yaml:"-"`
	Keys     []string `yaml:"keys"`
	Operator string   `yaml:"operator"`
}

func (s RuleSegment) MarshalYAML() (interface{}, error) {
	if s.Key != "" {
		return s.Key, nil
	}
	if len(s.Keys) == 1 {
		return s.Keys[0], nil
	}
	if s.Operator == "" {
		s.Operator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
	}

	type plain RuleSegment
	return plain(s), nil
}

func (s *RuleSegment) UnmarshalYAML(unmarshal func(interface{}) error) error {
	var key string
	if err := unmarshal(&key); err == nil {
		*s = RuleSegment{
			Key:      key,
			Operator: flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String(),
		}
		return nil
	}

	type plain RuleSegment
	var segment plain
	if err := unmarshal(&segment); err != nil {
		return err
	}
	*s = RuleSegment(segment)
	if len(s.Keys) == 1 {
		s.Key = s.Keys[0]
		s.Keys = nil
		s.Operator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
	}
	if s.Operator == "" {
		s.Operator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
	}
	return nil
}

type Distribution struct {
	VariantKey string  `yaml:"variant,omitempty"`
	Rollout    float32 `yaml:"rollout,omitempty"`
}

type Rollout struct {
	Description string         `yaml:"description,omitempty"`
	Segment     *SegmentRule   `yaml:"segment,omitempty"`
	Threshold   *ThresholdRule `yaml:"threshold,omitempty"`
}

type SegmentRule struct {
	Key      string   `yaml:"key,omitempty"`
	Keys     []string `yaml:"keys,omitempty"`
	Operator string   `yaml:"operator,omitempty"`
	Value    bool     `yaml:"value,omitempty"`
}

type ThresholdRule struct {
	Percentage float32 `yaml:"percentage,omitempty"`
	Value      bool    `yaml:"value,omitempty"`
}

type Segment struct {
	Key         string        `yaml:"key,omitempty"`
	Name        string        `yaml:"name,omitempty"`
	Description string        `yaml:"description,omitempty"`
	Constraints []*Constraint `yaml:"constraints,omitempty"`
	MatchType   string        `yaml:"match_type,omitempty"`
}

type Constraint struct {
	Type        string `yaml:"type,omitempty"`
	Property    string `yaml:"property,omitempty"`
	Operator    string `yaml:"operator,omitempty"`
	Value       string `yaml:"value,omitempty"`
	Description string `yaml:"description,omitempty"`
}
