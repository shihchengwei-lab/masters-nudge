package ext

import "go.flipt.io/flipt/rpc/flipt"

type Document struct {
	Version   string     `yaml:"version,omitempty"`
	Namespace string     `yaml:"namespace,omitempty"`
	Flags     []*Flag    `yaml:"flags,omitempty"`
	Segments  []*Segment `yaml:"segments,omitempty"`
}

type Flag struct {
	Key         string     `yaml:"key,omitempty"`
	Name        string     `yaml:"name,omitempty"`
	Type        string     `yaml:"type,omitempty"`
	Description string     `yaml:"description,omitempty"`
	Enabled     bool       `yaml:"enabled"`
	Variants    []*Variant `yaml:"variants,omitempty"`
	Rules       []*Rule    `yaml:"rules,omitempty"`
	Rollouts    []*Rollout `yaml:"rollouts,omitempty"`
}

type Variant struct {
	Key         string      `yaml:"key,omitempty"`
	Name        string      `yaml:"name,omitempty"`
	Description string      `yaml:"description,omitempty"`
	Attachment  interface{} `yaml:"attachment,omitempty"`
}

type Rule struct {
	SegmentKey      string          `yaml:"segment,omitempty"`
	Rank            uint            `yaml:"rank,omitempty"`
	SegmentKeys     []string        `yaml:"segments,omitempty"`
	SegmentOperator string          `yaml:"operator,omitempty"`
	Distributions   []*Distribution `yaml:"distributions,omitempty"`
}

// ruleSegments is the compound form of a rule's segment field. Rollout
// segments use SegmentRule instead, which also carries the rollout value.
type ruleSegments struct {
	Keys     []string `yaml:"keys"`
	Operator string   `yaml:"operator"`
}

func (r Rule) MarshalYAML() (interface{}, error) {
	var segment interface{}
	switch {
	case r.SegmentKey != "":
		segment = r.SegmentKey
	case len(r.SegmentKeys) == 1:
		segment = r.SegmentKeys[0]
	case len(r.SegmentKeys) > 1:
		operator := r.SegmentOperator
		if operator == "" {
			operator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
		}
		segment = ruleSegments{Keys: r.SegmentKeys, Operator: operator}
	}

	return struct {
		Segment       interface{}     `yaml:"segment,omitempty"`
		Rank          uint            `yaml:"rank,omitempty"`
		Distributions []*Distribution `yaml:"distributions,omitempty"`
	}{segment, r.Rank, r.Distributions}, nil
}

func (r *Rule) UnmarshalYAML(unmarshal func(interface{}) error) error {
	// Retain support for the previous top-level segments/operator format.
	var decoded struct {
		Segment         interface{}     `yaml:"segment"`
		Rank            uint            `yaml:"rank,omitempty"`
		SegmentKeys     []string        `yaml:"segments,omitempty"`
		SegmentOperator string          `yaml:"operator,omitempty"`
		Distributions   []*Distribution `yaml:"distributions,omitempty"`
	}
	if err := unmarshal(&decoded); err != nil {
		return err
	}
	*r = Rule{Rank: decoded.Rank, SegmentKeys: decoded.SegmentKeys,
		SegmentOperator: decoded.SegmentOperator, Distributions: decoded.Distributions}
	if key, ok := decoded.Segment.(string); ok {
		r.SegmentKey = key
	} else if decoded.Segment != nil {
		var compound struct {
			Segment ruleSegments `yaml:"segment"`
		}
		if err := unmarshal(&compound); err != nil {
			return err
		}
		r.SegmentKeys = compound.Segment.Keys
		r.SegmentOperator = compound.Segment.Operator
	}
	if r.SegmentKey != "" || len(r.SegmentKeys) == 1 {
		r.SegmentOperator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
	}
	return nil
}

type Distribution struct {
	VariantKey string  `yaml:"variant,omitempty"`
	Rollout    float32 `yaml:"rollout,omitempty"`
}

type Rollout struct {
	Description string         `yaml:"description,omitempty"`
	Segment     *SegmentRule   `yaml:"segment,omitempty"`
	Threshold   *ThresholdRule `yaml:"threshold,omitempty"`
}

type SegmentRule struct {
	Key      string   `yaml:"key,omitempty"`
	Keys     []string `yaml:"keys,omitempty"`
	Operator string   `yaml:"operator,omitempty"`
	Value    bool     `yaml:"value,omitempty"`
}

type ThresholdRule struct {
	Percentage float32 `yaml:"percentage,omitempty"`
	Value      bool    `yaml:"value,omitempty"`
}

type Segment struct {
	Key         string        `yaml:"key,omitempty"`
	Name        string        `yaml:"name,omitempty"`
	Description string        `yaml:"description,omitempty"`
	Constraints []*Constraint `yaml:"constraints,omitempty"`
	MatchType   string        `yaml:"match_type,omitempty"`
}

type Constraint struct {
	Type        string `yaml:"type,omitempty"`
	Property    string `yaml:"property,omitempty"`
	Operator    string `yaml:"operator,omitempty"`
	Value       string `yaml:"value,omitempty"`
	Description string `yaml:"description,omitempty"`
}
