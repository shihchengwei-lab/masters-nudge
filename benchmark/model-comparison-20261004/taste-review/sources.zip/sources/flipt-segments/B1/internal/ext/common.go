package ext

import (
	"fmt"

	"go.flipt.io/flipt/rpc/flipt"
)

type Document struct {
	Version   string     `yaml:"version,omitempty"`
	Namespace string     `yaml:"namespace,omitempty"`
	Flags     []*Flag    `yaml:"flags,omitempty"`
	Segments  []*Segment `yaml:"segments,omitempty"`
}

type Flag struct {
	Key         string     `yaml:"key,omitempty"`
	Name        string     `yaml:"name,omitempty"`
	Type        string     `yaml:"type,omitempty"`
	Description string     `yaml:"description,omitempty"`
	Enabled     bool       `yaml:"enabled"`
	Variants    []*Variant `yaml:"variants,omitempty"`
	Rules       []*Rule    `yaml:"rules,omitempty"`
	Rollouts    []*Rollout `yaml:"rollouts,omitempty"`
}

type Variant struct {
	Key         string      `yaml:"key,omitempty"`
	Name        string      `yaml:"name,omitempty"`
	Description string      `yaml:"description,omitempty"`
	Attachment  interface{} `yaml:"attachment,omitempty"`
}

type Rule struct {
	SegmentKey      string          `yaml:"segment,omitempty"`
	Rank            uint            `yaml:"rank,omitempty"`
	SegmentKeys     []string        `yaml:"segments,omitempty"`
	SegmentOperator string          `yaml:"operator,omitempty"`
	Distributions   []*Distribution `yaml:"distributions,omitempty"`
}

// ruleSegment is the rule-only YAML representation. Rollouts retain SegmentRule.
type ruleSegment struct {
	Keys     []string `yaml:"keys"`
	Operator string   `yaml:"operator"`
	scalar   bool
}

func (s ruleSegment) MarshalYAML() (interface{}, error) {
	if len(s.Keys) == 1 {
		return s.Keys[0], nil
	}
	if s.Operator == "" {
		s.Operator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
	}
	type plain ruleSegment
	return plain(s), nil
}

func (s *ruleSegment) UnmarshalYAML(unmarshal func(interface{}) error) error {
	var key string
	if err := unmarshal(&key); err == nil {
		*s = ruleSegment{Operator: flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String(), scalar: true}
		if key != "" {
			s.Keys = []string{key}
		}
		return nil
	}
	type plain ruleSegment
	var decoded plain
	if err := unmarshal(&decoded); err != nil {
		return err
	}
	*s = ruleSegment(decoded)
	return nil
}

type ruleYAML struct {
	Segment         *ruleSegment    `yaml:"segment,omitempty"`
	Rank            uint            `yaml:"rank,omitempty"`
	SegmentKeys     []string        `yaml:"segments,omitempty"`
	SegmentOperator string          `yaml:"operator,omitempty"`
	Distributions   []*Distribution `yaml:"distributions,omitempty"`
}

func (r Rule) MarshalYAML() (interface{}, error) {
	out := ruleYAML{Rank: r.Rank, Distributions: r.Distributions}
	keys := r.SegmentKeys
	if len(keys) == 0 && r.SegmentKey != "" {
		keys = []string{r.SegmentKey}
	}
	if len(keys) > 0 {
		out.Segment = &ruleSegment{Keys: keys, Operator: r.SegmentOperator}
	}
	return out, nil
}

func (r *Rule) UnmarshalYAML(unmarshal func(interface{}) error) error {
	var decoded ruleYAML
	if err := unmarshal(&decoded); err != nil {
		return err
	}
	*r = Rule{Rank: decoded.Rank, SegmentKeys: decoded.SegmentKeys, SegmentOperator: decoded.SegmentOperator, Distributions: decoded.Distributions}
	if decoded.Segment != nil {
		if !decoded.Segment.scalar && len(decoded.Segment.Keys) > 0 && len(decoded.SegmentKeys) > 0 {
			return fmt.Errorf("rule cannot have both segment.keys and segments")
		}
		if decoded.Segment.scalar && len(decoded.Segment.Keys) == 1 {
			r.SegmentKey = decoded.Segment.Keys[0]
		} else if !decoded.Segment.scalar {
			r.SegmentKeys = decoded.Segment.Keys
			r.SegmentOperator = decoded.Segment.Operator
		}
	}
	if r.SegmentKey != "" || len(r.SegmentKeys) == 1 {
		r.SegmentOperator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
	}
	return nil
}

type Distribution struct {
	VariantKey string  `yaml:"variant,omitempty"`
	Rollout    float32 `yaml:"rollout,omitempty"`
}

type Rollout struct {
	Description string         `yaml:"description,omitempty"`
	Segment     *SegmentRule   `yaml:"segment,omitempty"`
	Threshold   *ThresholdRule `yaml:"threshold,omitempty"`
}

type SegmentRule struct {
	Key      string   `yaml:"key,omitempty"`
	Keys     []string `yaml:"keys,omitempty"`
	Operator string   `yaml:"operator,omitempty"`
	Value    bool     `yaml:"value,omitempty"`
}

type ThresholdRule struct {
	Percentage float32 `yaml:"percentage,omitempty"`
	Value      bool    `yaml:"value,omitempty"`
}

type Segment struct {
	Key         string        `yaml:"key,omitempty"`
	Name        string        `yaml:"name,omitempty"`
	Description string        `yaml:"description,omitempty"`
	Constraints []*Constraint `yaml:"constraints,omitempty"`
	MatchType   string        `yaml:"match_type,omitempty"`
}

type Constraint struct {
	Type        string `yaml:"type,omitempty"`
	Property    string `yaml:"property,omitempty"`
	Operator    string `yaml:"operator,omitempty"`
	Value       string `yaml:"value,omitempty"`
	Description string `yaml:"description,omitempty"`
}
