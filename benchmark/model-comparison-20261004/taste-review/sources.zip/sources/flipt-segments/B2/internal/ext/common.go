package ext

import (
	"fmt"

	"go.flipt.io/flipt/rpc/flipt"
)

type Document struct {
	Version   string     `yaml:"version,omitempty"`
	Namespace string     `yaml:"namespace,omitempty"`
	Flags     []*Flag    `yaml:"flags,omitempty"`
	Segments  []*Segment `yaml:"segments,omitempty"`
}

type Flag struct {
	Key         string     `yaml:"key,omitempty"`
	Name        string     `yaml:"name,omitempty"`
	Type        string     `yaml:"type,omitempty"`
	Description string     `yaml:"description,omitempty"`
	Enabled     bool       `yaml:"enabled"`
	Variants    []*Variant `yaml:"variants,omitempty"`
	Rules       []*Rule    `yaml:"rules,omitempty"`
	Rollouts    []*Rollout `yaml:"rollouts,omitempty"`
}

type Variant struct {
	Key         string      `yaml:"key,omitempty"`
	Name        string      `yaml:"name,omitempty"`
	Description string      `yaml:"description,omitempty"`
	Attachment  interface{} `yaml:"attachment,omitempty"`
}

type Rule struct {
	SegmentKey      string          `yaml:"segment,omitempty"`
	Rank            uint            `yaml:"rank,omitempty"`
	SegmentKeys     []string        `yaml:"segments,omitempty"`
	SegmentOperator string          `yaml:"operator,omitempty"`
	Distributions   []*Distribution `yaml:"distributions,omitempty"`
}

// MarshalYAML keeps single-segment rules compact and groups compound targets
// under the same segment field.
func (r Rule) MarshalYAML() (interface{}, error) {
	var segment interface{}
	switch {
	case r.SegmentKey != "":
		segment = r.SegmentKey
	case len(r.SegmentKeys) == 1:
		segment = r.SegmentKeys[0]
	case len(r.SegmentKeys) > 1:
		operator := r.SegmentOperator
		if operator == "" {
			operator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
		}
		segment = struct {
			Keys     []string `yaml:"keys"`
			Operator string   `yaml:"operator"`
		}{r.SegmentKeys, operator}
	}
	return struct {
		Segment       interface{}     `yaml:"segment,omitempty"`
		Rank          uint            `yaml:"rank,omitempty"`
		Distributions []*Distribution `yaml:"distributions,omitempty"`
	}{segment, r.Rank, r.Distributions}, nil
}

func (r *Rule) UnmarshalYAML(unmarshal func(interface{}) error) error {
	// Keep accepting the legacy top-level segments/operator fields on input.
	var raw struct {
		Segment       interface{}     `yaml:"segment"`
		SegmentKeys   []string        `yaml:"segments"`
		Operator      string          `yaml:"operator"`
		Rank          uint            `yaml:"rank"`
		Distributions []*Distribution `yaml:"distributions"`
	}
	if err := unmarshal(&raw); err != nil {
		return err
	}
	decoded := Rule{SegmentKeys: raw.SegmentKeys, SegmentOperator: raw.Operator, Rank: raw.Rank, Distributions: raw.Distributions}
	switch segment := raw.Segment.(type) {
	case nil:
	case string:
		decoded.SegmentKey = segment
	case map[interface{}]interface{}, map[string]interface{}:
		if len(raw.SegmentKeys) > 0 || raw.Operator != "" {
			return fmt.Errorf("rule cannot combine segment object with legacy segments or operator")
		}
		var compound struct {
			Segment struct {
				Keys     []string `yaml:"keys"`
				Operator string   `yaml:"operator"`
			} `yaml:"segment"`
		}
		if err := unmarshal(&compound); err != nil {
			return err
		}
		decoded.SegmentKeys = compound.Segment.Keys
		decoded.SegmentOperator = compound.Segment.Operator
	default:
		return fmt.Errorf("rule segment must be a string or an object with keys and operator")
	}
	if decoded.SegmentKey != "" || len(decoded.SegmentKeys) == 1 {
		decoded.SegmentOperator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
		if decoded.SegmentKey == "" {
			decoded.SegmentKey = decoded.SegmentKeys[0]
			decoded.SegmentKeys = nil
		}
	}
	*r = decoded
	return nil
}

type Distribution struct {
	VariantKey string  `yaml:"variant,omitempty"`
	Rollout    float32 `yaml:"rollout,omitempty"`
}

type Rollout struct {
	Description string         `yaml:"description,omitempty"`
	Segment     *SegmentRule   `yaml:"segment,omitempty"`
	Threshold   *ThresholdRule `yaml:"threshold,omitempty"`
}

type SegmentRule struct {
	Key      string   `yaml:"key,omitempty"`
	Keys     []string `yaml:"keys,omitempty"`
	Operator string   `yaml:"operator,omitempty"`
	Value    bool     `yaml:"value,omitempty"`
}

type ThresholdRule struct {
	Percentage float32 `yaml:"percentage,omitempty"`
	Value      bool    `yaml:"value,omitempty"`
}

type Segment struct {
	Key         string        `yaml:"key,omitempty"`
	Name        string        `yaml:"name,omitempty"`
	Description string        `yaml:"description,omitempty"`
	Constraints []*Constraint `yaml:"constraints,omitempty"`
	MatchType   string        `yaml:"match_type,omitempty"`
}

type Constraint struct {
	Type        string `yaml:"type,omitempty"`
	Property    string `yaml:"property,omitempty"`
	Operator    string `yaml:"operator,omitempty"`
	Value       string `yaml:"value,omitempty"`
	Description string `yaml:"description,omitempty"`
}
