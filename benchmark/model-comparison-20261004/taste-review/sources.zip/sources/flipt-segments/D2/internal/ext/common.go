package ext

import (
	"fmt"

	"go.flipt.io/flipt/rpc/flipt"
)

type Document struct {
	Version   string     `yaml:"version,omitempty"`
	Namespace string     `yaml:"namespace,omitempty"`
	Flags     []*Flag    `yaml:"flags,omitempty"`
	Segments  []*Segment `yaml:"segments,omitempty"`
}

type Flag struct {
	Key         string     `yaml:"key,omitempty"`
	Name        string     `yaml:"name,omitempty"`
	Type        string     `yaml:"type,omitempty"`
	Description string     `yaml:"description,omitempty"`
	Enabled     bool       `yaml:"enabled"`
	Variants    []*Variant `yaml:"variants,omitempty"`
	Rules       []*Rule    `yaml:"rules,omitempty"`
	Rollouts    []*Rollout `yaml:"rollouts,omitempty"`
}

type Variant struct {
	Key         string      `yaml:"key,omitempty"`
	Name        string      `yaml:"name,omitempty"`
	Description string      `yaml:"description,omitempty"`
	Attachment  interface{} `yaml:"attachment,omitempty"`
}

type Rule struct {
	SegmentKey      string          `yaml:"segment,omitempty"`
	Rank            uint            `yaml:"rank,omitempty"`
	SegmentKeys     []string        `yaml:"segments,omitempty"`
	SegmentOperator string          `yaml:"operator,omitempty"`
	Distributions   []*Distribution `yaml:"distributions,omitempty"`
}

// ruleSegment decodes the two YAML forms without changing the internal rule
// fields. The callback form of UnmarshalYAML works with both yaml.v2 and yaml.v3.
type ruleSegment struct {
	Key      string   `yaml:"-"`
	Keys     []string `yaml:"keys"`
	Operator string   `yaml:"operator"`
}

func (s *ruleSegment) UnmarshalYAML(unmarshal func(interface{}) error) error {
	var value interface{}
	if err := unmarshal(&value); err != nil {
		return err
	}

	switch value := value.(type) {
	case string:
		*s = ruleSegment{Key: value}
	case map[interface{}]interface{}, map[string]interface{}:
		type plain ruleSegment
		var segment plain
		if err := unmarshal(&segment); err != nil {
			return err
		}
		*s = ruleSegment(segment)
	case nil:
		*s = ruleSegment{}
	default:
		return fmt.Errorf("rule segment must be a string or an object with keys and operator")
	}
	return nil
}

func (r Rule) MarshalYAML() (interface{}, error) {
	var segment interface{}
	switch {
	case r.SegmentKey != "":
		segment = r.SegmentKey
	case len(r.SegmentKeys) == 1:
		segment = r.SegmentKeys[0]
	case len(r.SegmentKeys) > 1:
		operator := r.SegmentOperator
		if operator == "" {
			operator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
		}
		segment = ruleSegment{Keys: r.SegmentKeys, Operator: operator}
	}
	return struct {
		Segment       interface{}     `yaml:"segment,omitempty"`
		Rank          uint            `yaml:"rank,omitempty"`
		Distributions []*Distribution `yaml:"distributions,omitempty"`
	}{segment, r.Rank, r.Distributions}, nil
}

func (r *Rule) UnmarshalYAML(unmarshal func(interface{}) error) error {
	var fields struct {
		Segment         ruleSegment     `yaml:"segment"`
		Rank            uint            `yaml:"rank"`
		SegmentKeys     []string        `yaml:"segments"`
		SegmentOperator string          `yaml:"operator"`
		Distributions   []*Distribution `yaml:"distributions"`
	}
	if err := unmarshal(&fields); err != nil {
		return err
	}
	if len(fields.SegmentKeys) > 0 && (fields.Segment.Key != "" || len(fields.Segment.Keys) > 0) {
		return fmt.Errorf("rule cannot have both segment and segments")
	}
	*r = Rule{
		SegmentKey:      fields.Segment.Key,
		SegmentKeys:     fields.SegmentKeys,
		SegmentOperator: fields.SegmentOperator,
		Rank:            fields.Rank,
		Distributions:   fields.Distributions,
	}
	if len(fields.Segment.Keys) > 0 {
		r.SegmentKeys = fields.Segment.Keys
		r.SegmentOperator = fields.Segment.Operator
	}
	if len(r.SegmentKeys) == 1 {
		r.SegmentKey = r.SegmentKeys[0]
		r.SegmentKeys = nil
	}
	if r.SegmentKey != "" || r.SegmentOperator == "" {
		r.SegmentOperator = flipt.SegmentOperator_OR_SEGMENT_OPERATOR.String()
	}
	return nil
}

type Distribution struct {
	VariantKey string  `yaml:"variant,omitempty"`
	Rollout    float32 `yaml:"rollout,omitempty"`
}

type Rollout struct {
	Description string         `yaml:"description,omitempty"`
	Segment     *SegmentRule   `yaml:"segment,omitempty"`
	Threshold   *ThresholdRule `yaml:"threshold,omitempty"`
}

type SegmentRule struct {
	Key      string   `yaml:"key,omitempty"`
	Keys     []string `yaml:"keys,omitempty"`
	Operator string   `yaml:"operator,omitempty"`
	Value    bool     `yaml:"value,omitempty"`
}

type ThresholdRule struct {
	Percentage float32 `yaml:"percentage,omitempty"`
	Value      bool    `yaml:"value,omitempty"`
}

type Segment struct {
	Key         string        `yaml:"key,omitempty"`
	Name        string        `yaml:"name,omitempty"`
	Description string        `yaml:"description,omitempty"`
	Constraints []*Constraint `yaml:"constraints,omitempty"`
	MatchType   string        `yaml:"match_type,omitempty"`
}

type Constraint struct {
	Type        string `yaml:"type,omitempty"`
	Property    string `yaml:"property,omitempty"`
	Operator    string `yaml:"operator,omitempty"`
	Value       string `yaml:"value,omitempty"`
	Description string `yaml:"description,omitempty"`
}
