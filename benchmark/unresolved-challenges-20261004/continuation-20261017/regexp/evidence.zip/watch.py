"""Emit meaningful Actor/Nudge events; no test or Actor control."""
from pathlib import Path
import json
import sqlite3
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')

root=Path(__file__).resolve().parent
events=root/'run/actor-events.jsonl'
offset=0
attempts={}
while True:
    if events.exists():
        with events.open(encoding='utf-8') as f:
            f.seek(offset)
            while True:
                start=f.tell();line=f.readline()
                if not line or not line.endswith('\n'):
                    f.seek(start);break
                try:e=json.loads(line)
                except ValueError:continue
                item=e.get('item',{})
                if e.get('type')=='item.completed' and item.get('type')=='agent_message':
                    print(json.dumps({'actor_message':item.get('text','')},ensure_ascii=False),flush=True)
                if e.get('type')=='item.completed' and item.get('type')=='file_change':
                    print(json.dumps({'file_change':item.get('changes',[]),'status':item.get('status')},ensure_ascii=False),flush=True)
                if e.get('type') in ('turn.completed','turn.failed','error'):
                    print(json.dumps(e,ensure_ascii=False),flush=True)
            offset=f.tell()
    db=root/'run/masters-nudge-data/feedback.sqlite3'
    if db.exists():
        with sqlite3.connect(db) as c:
            c.row_factory=sqlite3.Row
            for row in c.execute('SELECT id,outcome,delivered,detail FROM attempts ORDER BY started'):
                row=dict(row)
                if attempts.get(row['id'])!=row:
                    attempts[row['id']]=row.copy()
                    if row['detail']:
                        d=json.loads(row['detail'])
                        row['detail']={k:d[k] for k in ('raw_output','usage','elapsed_seconds','fault') if k in d}
                    print(json.dumps({'nudge_attempt':row},ensure_ascii=False),flush=True)
    if (root/'run/result.json').exists():break
    time.sleep(1)
