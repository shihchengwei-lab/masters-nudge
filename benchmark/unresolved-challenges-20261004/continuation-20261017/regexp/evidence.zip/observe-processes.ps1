param([Parameter(Mandatory=$true)][string]$ExperimentRoot)
$ErrorActionPreference = 'Stop'
$processLog = Join-Path $ExperimentRoot 'run\actual-processes.jsonl'
$stopFile = Join-Path $ExperimentRoot 'run\observer-stop'
$seenProcesses = @{}
Set-Content -LiteralPath (Join-Path $ExperimentRoot 'run\observer-ready') -Value 'ready' -Encoding utf8
while (-not (Test-Path -LiteralPath $stopFile)) {
    foreach ($observed in (Get-CimInstance Win32_Process -Filter "Name='codex.exe'")) {
        if (-not $seenProcesses.ContainsKey($observed.ProcessId) -and $observed.CommandLine -like ('*' + $ExperimentRoot + '*')) {
            $seenProcesses[$observed.ProcessId] = $true
            [pscustomobject]@{ observed_utc=[DateTime]::UtcNow.ToString('o'); pid=$observed.ProcessId; parent_pid=$observed.ParentProcessId; executable=$observed.ExecutablePath; command_line=$observed.CommandLine } |
                ConvertTo-Json -Compress | Add-Content -LiteralPath $processLog -Encoding utf8
        }
    }
    Start-Sleep -Seconds 2
}
