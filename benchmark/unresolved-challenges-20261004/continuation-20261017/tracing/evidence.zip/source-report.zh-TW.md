# Tracing L2 續解交付

2026-10-17。完整固定驗收 **4/4 通過**，目前沒有未解決的驗收缺口。

本次從精確基底 `ac4a8dd27c0b28c36b9cf77cdc52b595168d1c5f` 套用歷史 L2 patch 後續解，已提供原題、L1／L2 原始修改與失敗反例。這是知悉歷史結果的續解，不能用來推算 Nudge 的因果效果，也不改寫先前實驗的失敗結果。

## 交付檔案

- [完整 patch](<STUDY_ROOT>/tracing-l2-continuation-20261017/final.patch)：包含 L2 與本次修補，可套用至上述基底。
- [僅本次增量 patch](<STUDY_ROOT>/tracing-l2-continuation-20261017/continuation-only.patch)：相對於歷史 L2，6 個實作檔及 1 個新增測試檔，482 行新增、22 行刪除。
- [實作、完整命令與回歸測試說明](<STUDY_ROOT>/tracing-l2-continuation-20261017/continuation-report.zh-TW.md)。
- [最終固定驗收](<STUDY_ROOT>/tracing-l2-continuation-20261017/actor-evaluation-2/evidence.json)、[最終測試摘要](<STUDY_ROOT>/tracing-l2-continuation-20261017/continuation-verification.json)。
- [完整稽核摘要](<STUDY_ROOT>/tracing-l2-continuation-20261017/audit-summary.json)、[Actor 原始事件](<STUDY_ROOT>/tracing-l2-continuation-20261017/run/actor-events.jsonl)、[58 則命令及輸出](<STUDY_ROOT>/tracing-l2-continuation-20261017/commands.json)。

完整 patch 的 SHA-256：`03aa139826be0e426a5b6a52f368051bdbf899112e96fbe14468102b4f28b486`。它與已驗收的第二版候選位元組相同，交付內容不包含安裝到測試 checkout 的固定驗收材料。

工作目錄：`<STUDY_ROOT>\tracing-l2-continuation-20261017\calibration\cases\tracing-1523`。

## 修正與結果

1. **全域拒絕與層級上限穿過局部包裝仍生效。** `Filtered` 分別傳遞 global 與 consumers，涵蓋 enabled、callsite 與 max hint，保留純全域 filter 不算消費者的行為。
2. **filtered current 依仍在進入中的 span 查找。** Registry 使用原有堆疊；自訂 subscriber 在 Layered 邊界追蹤。current、lookup 與 contextual event scope 使用同一視圖；進入／離開先更新，再派送回呼，以處理重入。
3. **一般快取重建保留待派送決策，真正 reload 才使其失效。** 功能組合測試發現 L2 的動態 filter 在並行時可能多求值；新增穩定反例後修正，並保留動態 reload 的失效行為。

新增 8 項回歸測試；原有 L2 測試及固定驗收測試未修改。最初 4 項新回歸失敗、重入失敗、快取反例及第一次 registry-only 的 5／3 求值差異，都保留在本次目錄。第一版已通過固定驗收，因後續功能檢查發現快取問題而繼續修到第二版。

| 固定檢查 | 重現 L2 | 最終交付 |
| --- | --- | --- |
| reserved | pass，148／148 | pass，148／148 |
| tracing_contract_v2.rs | fail | pass，5 個探針 |
| tracing_hint_bounds.rs | pass | pass，1 個探針 |
| tracing_judge_concerns.rs | fail | pass，4 個探針 |

10 個固定探針均已核對 `passed:true`，沒有只憑 Cargo 結束碼判定。原先兩個失敗已分別改為 `events=0` 與 `observations=[["visible","visible"]]`。

| 最終功能檢查 | 通過 | 失敗 | 原有忽略 | 日誌 |
| --- | ---: | ---: | ---: | --- |
| 指定完整預設功能測試 | 184 | 0 | 3 | full-tests-final.txt |
| 無預設功能、registry 的受影響測試 | 88 | 0 | 0 | registry-only-final.txt |
| 無預設功能、registry＋env-filter＋regex/unicode 完整測試 | 141 | 0 | 3 | registry-env-final.txt |
| 無預設功能的 library／公開 layering 測試 | 15 | 0 | 0 | std-only-tests.txt |

無預設功能編譯、修改檔格式與差異檢查皆 exit 0。各組測試重疊，數量不相加。

## 實際模型與用量

隔離 CLI Actor 及 Nudge Provider 都是 **gpt-6.1-sol／xhigh**。專屬設定已透過 select-provider 技能的 CLI 寫入並讀回；另以程序紀錄核對 1 個 Actor 及 4 個 Provider 的實際命令列，全部符合。Provider runtime 的推理深度也是 xhigh。桌面預設 Provider 與日常產品原始碼未調整。

- Actor：**1,047.297 秒，約 17 分 27 秒**，包含同步等待 Provider 及測試／驗收；沒有總時限。
- Provider 呼叫合計：205.922 秒，已包含在上述 Actor 時間內，不重複相加。
- 起始固定驗收重現：143.938 秒；Actor 內兩次固定驗收分別為 76.031、86.875 秒。
- [實際程序與模型紀錄](<STUDY_ROOT>/tracing-l2-continuation-20261017/actual-models.json)、[啟動 argv 與環境](<STUDY_ROOT>/tracing-l2-continuation-20261017/run/launch.json)、[Provider 選擇讀回](<STUDY_ROOT>/tracing-l2-continuation-20261017/provider-selection.json)。

| Token 用量 | Actor | Provider | 合計 |
| --- | ---: | ---: | ---: |
| 輸入，含快取 | 7,133,348 | 383,120 | 7,516,468 |
| 其中快取輸入 | 6,939,904 | 279,808 | 7,219,712 |
| 未快取輸入 | 193,444 | 103,312 | 296,756 |
| 輸出 | 42,313 | 7,012 | 49,325 |
| 其中 reasoning 輸出 | 18,995 | 5,212 | 24,207 |

輸入為各模型呼叫的累計，包含反覆讀取的上下文；reasoning 是輸出的子集。此表只計隔離 Actor 與 Provider，不含桌面協調 session。

## 每則 Nudge 的內容與處理

4 次 Provider 呼叫：3 則提醒、3 則送達、1 次沉默、0 次故障；另有 4 次測試 patch 被工具略過。三則提醒額度用完後沒有關閉 Nudge。完整原始內容、送達欄位、用量與讀取軌跡見 [nudge-attempts.json](<STUDY_ROOT>/tracing-l2-continuation-20261017/nudge-attempts.json)；對應 patch 事件見 [nudge-batches.json](<STUDY_ROOT>/tracing-l2-continuation-20261017/nudge-batches.json)。

### 1：8293e944，已送達

> required：current 可查得仍進入的可見根 span  
> observed：current_span_filtered@182: 無呼叫點  
> why：獨立進入的可見根仍可能被遮蔽  
> structure：Context.current_span→訂閱器的 entered stack→首個可見項

採納。Actor 明確承認方法尚未接線，接上 `Context.current_span` 與 Registry／自訂 subscriber 的堆疊。兩種 subscriber 的回歸測試及固定 current-view 探針通過。這項接線也已在 Actor 原先計畫內，不能把結果單獨歸因於提醒。

### 2：6141bc40，已送達

> required：重入事件取得當下的 filtered current  
> observed：enter@822: inner.enter→stack.push  
> why：內層回呼重入時外層可能讀到舊 span  
> structure：subscriber 邊界先更新唯一 entered stack 再派送回呼；各層 Context 共用

採納行為要求及更新順序，未採跨任意 subscriber 共用唯一堆疊的額外結構。`Layered.enter` 改為先 push 再呼叫 inner；exit 先 pop。每個 subscriber 邊界保留自身堆疊，其 Context／子樹沿用該視圖。重入回歸測試先失敗，修改後通過。

### 3：a1615413，已送達

> required：on_enter 重入事件可見剛進入的可見 span  
> observed：enter@822:inner.enter→stack.push  
> why：內層回呼重入時外層可能讀到舊 span  
> structure：訂閱器邊界維護唯一 entered stack；先更新，再派送 inner/layer 回呼

與第二則重複指出同一個順序問題。採納範圍及對應修改相同，以 `custom_subscriber_updates_current_before_reentrant_callbacks` 和最終完整測試驗證；不算成另一項獨立改善。

另一次 `af5b074b` 回傳 `{"feedback":null}`，沒有提醒可送達或採納。

## 材料完整性與範圍

桌面協調端另核對 **69 個既有測試檔**，全部未改；所有凍結輸入雜湊一致。原始來源 checkout 的 HEAD 與完整狀態清單相同，來源原有修改未帶入本次乾淨基底。Masters’ Nudge 專案目前工作目錄仍乾淨。

只執行 tracing-1523；沒有啟動多題矩陣、委派、提交、推送或建立 PR。歷史報告、兩份原始 patch、驗收定義與先前結果均保留。

準備階段的 WMI 事件訂閱曾遭權限拒絕，Actor 尚未啟動；之後改用一般使用者可讀的程序查詢，沒有提權。該次準備失敗保存在 `run/observer-start-failure`。實際解題 Actor 只啟動一次。
