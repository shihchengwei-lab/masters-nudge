"""Collect this continuation's raw audit without changing implementation or tests."""
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import continuation as c

def parsed(text):
    try:return json.loads(text)
    except (ValueError,TypeError):return text

assert (c.RUN/'result.json').exists(), 'Actor must finish first'
c.export_patch(c.ROOT/'final.patch')
events=[json.loads(line) for line in (c.RUN/'actor-events.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
commands=[]
changes=[]
messages=[]
for number,event in enumerate(events,1):
    if event.get('type')!='item.completed':continue
    item=event.get('item',{})
    if item.get('type')=='command_execution':
        commands.append({'event_line':number,'id':item.get('id'),'command':item.get('command'),
            'exit_code':item.get('exit_code'),'output':item.get('aggregated_output','')})
    elif item.get('type')=='file_change':changes.append({'event_line':number,**item})
    elif item.get('type')=='agent_message':messages.append({'event_line':number,**item})
c.save(c.ROOT/'commands.json',commands)
c.save(c.ROOT/'file-changes.json',changes)
c.save(c.ROOT/'actor-messages.json',messages)

with sqlite3.connect(c.DATA/'feedback.sqlite3') as db:
    db.row_factory=sqlite3.Row
    for table in ('attempts','batches','judgment_events','rounds'):
        rows=[]
        for row in db.execute('SELECT * FROM '+table):
            row=dict(row)
            for key in ('detail','payload'):
                if key in row:row[key]=parsed(row[key])
            rows.append(row)
        c.save(c.ROOT/('nudge-'+table+'.json'),rows)
attempts=c.read(c.ROOT/'nudge-attempts.json')

tests=c.read(c.ROOT/'all-existing-test-hashes.json')
test_changes=[n for n,h in tests.items() if not (c.WORK/n).is_file() or c.sha(c.WORK/n)!=h]
inputs=c.read(c.ROOT/'input-hashes.json')
input_changes=[n for n,h in inputs.items() if not (c.ROOT/n).is_file() or c.sha(c.ROOT/n)!=h]
source=c.read(c.ROOT/'source-before.json')
source_after={'head':c.run(['git','rev-parse','HEAD'],c.SOURCE).strip(),
    'status':c.run(['git','status','--porcelain=v1','--untracked-files=all'],c.SOURCE)}
source_same=source['head']==source_after['head'] and source['status']==source_after['status']

# Compare against L2 using a private index. No commits, resets or test edits.
private_index=c.ROOT/'l2-baseline.index'
assert not private_index.exists(), 'Do not replace a previous audit'
e=os.environ.copy();e['GIT_INDEX_FILE']=str(private_index)
c.run(['git','read-tree',c.BASE],c.WORK,e)
c.run(['git','apply','--cached','--whitespace=nowarn',str(c.ROOT/'historical-materials/L2/final.patch')],c.WORK,e)
c.run(['git','add','-N','.'],c.WORK,e)
fixed=re.findall(r'^diff --git a/(.*?) b/.*$',(c.EVAL/'cases/tracing-1523/test.patch').read_text(),re.M)
fixed+=['Cargo.lock','tracing-subscriber/tests/benchmark_public_layer_tests.rs']
fixed+=['tracing-subscriber/tests/contract_'+n.replace('.','_')+'.rs' for n in
    ('tracing_contract_v2.rs','tracing_hint_bounds.rs','tracing_judge_concerns.rs')]
paths=['.',*[':(exclude)'+n for n in fixed]]
delta=subprocess.run(['git','diff','--binary','--',*paths],cwd=c.WORK,env=e,capture_output=True,check=True)
(c.ROOT/'continuation-only.patch').write_bytes(delta.stdout)
stat=c.run(['git','diff','--stat','--',*paths],c.WORK,e)

actual=[]
for row in (c.RUN/'actual-processes.jsonl').read_text(encoding='utf-8-sig').splitlines():
    r=json.loads(row);command=r['command_line']
    r['role']='provider' if 'mcp_servers.readrepo' in command else 'actor'
    r['expected_model_present']='-m gpt-6.1-sol' in command
    r['expected_effort_present']='model_reasoning_effort' in command and 'xhigh' in command
    actual.append(r)
c.save(c.ROOT/'actual-models.json',actual)

keys=('input_tokens','cached_input_tokens','output_tokens','reasoning_output_tokens')
actor=c.read(c.RUN/'result.json')['actor_usage']
provider={k:(sum(x['detail']['usage'][k] for x in attempts) if all(k in x.get('detail',{}).get('usage',{}) for x in attempts) else None) for k in keys}
totals={k:(actor.get(k)+provider[k] if actor.get(k) is not None and provider[k] is not None else None) for k in keys}
summary={'base_commit':c.BASE,'full_patch_sha256':c.sha(c.ROOT/'final.patch'),
    'continuation_patch_sha256':c.sha(c.ROOT/'continuation-only.patch'),'continuation_stat':stat,
    'existing_test_file_count':len(tests),'existing_test_changes':test_changes,'frozen_input_changes':input_changes,
    'source_head_and_status_unchanged':source_same,'source_after':source_after,
    'actor_usage':actor,'provider_usage':provider,'actor_plus_provider_usage':totals,
    'actor_elapsed_seconds':c.read(c.RUN/'result.json')['elapsed_seconds'],
    'provider_elapsed_seconds':sum(x.get('detail',{}).get('elapsed_seconds',0) for x in attempts),
    'attempts':[{k:x.get(k) for k in ('id','outcome','delivered','started','finished')} for x in attempts],
    'actual_actor_count':sum(x['role']=='actor' for x in actual),
    'actual_provider_count':sum(x['role']=='provider' for x in actual),
    'all_observed_models_match':all(x['expected_model_present'] and x['expected_effort_present'] for x in actual)}
c.save(c.ROOT/'audit-summary.json',summary)
print(json.dumps(summary,ensure_ascii=True,indent=2))
assert not test_changes and not input_changes and source_same
assert summary['all_observed_models_match'] and summary['actual_actor_count']==1
