"""Single-case continuation. Never resets or cleans a historical checkout."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
HISTORY = Path('<STUDY_ROOT>/astra-max-dual-tracing-2trial-unlimited-20261004')
TOOLS = Path('<STUDY_ROOT>/sol61-i-xhigh-sol-xhigh-provider-12case-20261004')
SOURCE = Path('<SOURCE_ROOT>/round-10-calibration/cases/tracing-1523')
BASE = 'ac4a8dd27c0b28c36b9cf77cdc52b595168d1c5f'
CAL = ROOT / 'calibration'
WORK = CAL / 'cases/tracing-1523'
PACKAGE = ROOT / 'frozen-plugin'
BINARY = ROOT / 'frozen-cli/codex.exe'
EVAL = ROOT / 'frozen-evaluation'
DATA = ROOT / 'run/masters-nudge-data'
RUN = ROOT / 'run'

def now(): return datetime.now(timezone.utc).isoformat()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p, obj):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    Path(p).write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def run(args, cwd=ROOT, env=None):
    return subprocess.run(list(map(str,args)), cwd=cwd, env=env, capture_output=True, check=True).stdout.decode('utf-8', errors='replace')
def environment():
    e = os.environ.copy()
    e.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
        CARGO_BUILD_JOBS='2', RUSTFLAGS='-Awarnings', CARGO_TARGET_DIR=str(ROOT/'actor-build'),
        TEMP=str(ROOT/'temp'), TMP=str(ROOT/'temp'), MASTERS_NUDGE_ACTIVE='0',
        MASTERS_NUDGE_TEST_MODE='1', PLUGIN_ROOT=str(PACKAGE),
        MASTERS_NUDGE_DATA_DIR=str(DATA), MASTERS_NUDGE_RUNTIME_DIR=str(PACKAGE))
    e['PATH'] = str(BINARY.parent)+os.pathsep+e.get('PATH','')
    return e

def prepare():
    assert not WORK.exists(), 'Refuse to overwrite a continuation checkout'
    (ROOT/'temp').mkdir(exist_ok=True)
    RUN.mkdir(exist_ok=True)
    DATA.mkdir(exist_ok=True)
    material = ROOT/'historical-materials'
    material.mkdir(exist_ok=True)
    source_status = run(['git','status','--porcelain=v1','--untracked-files=all'], SOURCE)
    save(ROOT/'source-before.json', {'source':str(SOURCE), 'head':run(['git','rev-parse','HEAD'], SOURCE).strip(),
        'status':source_status, 'created_utc':now()})
    for trial in ('L1','L2'):
        shutil.copytree(HISTORY/f'runs/tracing-1523/{trial}', material/trial,
            ignore=shutil.ignore_patterns('masters-nudge-data','actor-events.jsonl','actor-stderr.txt'))
    shutil.copytree(HISTORY/'frozen-evaluation', EVAL, ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    shutil.copytree(TOOLS/'frozen-plugin', PACKAGE, ignore=shutil.ignore_patterns('__pycache__','*.pyc','.pytest_cache'))
    shutil.copytree(TOOLS/'frozen-cli', BINARY.parent)
    WORK.parent.mkdir(parents=True, exist_ok=True)
    run(['git','clone','--shared','--no-checkout',str(SOURCE),str(WORK)])
    run(['git','-c','core.autocrlf=false','checkout','--detach',BASE], WORK)
    assert not run(['git','status','--porcelain'], WORK).strip()
    run(['git','apply','--whitespace=nowarn',str(material/'L2/final.patch')], WORK)
    # Fixed tests are installed exactly as the original evaluator installs them.
    # L2's added regression tests are left intact; the reserved surface is immutable.
    run(['git','apply','--check',str(EVAL/'cases/tracing-1523/test.patch')], WORK)
    run(['git','apply','--whitespace=nowarn',str(EVAL/'cases/tracing-1523/test.patch')], WORK)
    trees = WORK/'tracing-subscriber/tests/layer_filters/trees.rs'
    t = trees.read_text(encoding='utf-8')
    assert t.count('dbg!(subscriber)') == 2
    trees.write_text(t.replace('dbg!(subscriber)','subscriber'),encoding='utf-8')
    checks = EVAL/'cases/tracing-1523/checks'
    shutil.copyfile(checks/'benchmark_public_layer_tests.rs',WORK/'tracing-subscriber/tests/benchmark_public_layer_tests.rs')
    for name in ('tracing_contract_v2.rs','tracing_hint_bounds.rs','tracing_judge_concerns.rs'):
        shutil.copyfile(checks/name, WORK/'tracing-subscriber/tests'/('contract_'+name.replace('.','_')+'.rs'))
    shutil.copyfile(EVAL/'cases/tracing-1523/Cargo.lock',WORK/'Cargo.lock')
    e = environment()
    set_args = [sys.executable,str(PACKAGE/'masters_nudge_cli.py'),'provider','set','openai','--model','gpt-6.1-sol']
    get_args = [sys.executable,str(PACKAGE/'masters_nudge_cli.py'),'provider','get','--host','codex']
    selection = run(set_args,env=e)
    selected = run(get_args,env=e)
    runtime = run([sys.executable,'-c',
        'from masters_nudge.runtime import RuntimeSettings, PROVIDER_REASONING_EFFORT; import json; s=RuntimeSettings.from_env(host="codex"); print(json.dumps({"model":s.model,"reasoning":PROVIDER_REASONING_EFFORT,"strict":s.strict,"data":str(s.paths.data_dir)}))'], PACKAGE, e)
    actual = json.loads(runtime)
    assert actual['model']=='gpt-6.1-sol' and actual['reasoning']=='xhigh'
    save(ROOT/'provider-selection.json',{'set_command':set_args,'set_output':selection,'get_command':get_args,
        'get_output':selected,'imported_runtime':actual, 'runtime_test':False})
    files = {}
    for area in (EVAL, PACKAGE, material):
        for p in area.rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts: files[p.relative_to(ROOT).as_posix()] = sha(p)
    save(ROOT/'input-hashes.json',files)
    immutable = {}
    for p in (WORK/'tracing-subscriber/tests').rglob('*'):
        if p.is_file(): immutable[p.relative_to(WORK).as_posix()] = sha(p)
    save(ROOT/'immutable-test-hashes.json',immutable)
    save(ROOT/'plan.json',{'task':'tracing-1523 L2 continuation, informed by historical failures',
        'created_utc':now(),'base_commit':BASE,'initial_patch':str(material/'L2/final.patch'),
        'initial_patch_sha256':sha(material/'L2/final.patch'),'actor_model':'gpt-6.1-sol','actor_reasoning':'xhigh',
        'provider_model':'gpt-6.1-sol','provider_reasoning':'xhigh','actor_timeout_seconds':None,
        'historical_trial_root':str(HISTORY),'source_read_only':str(SOURCE),'work':str(WORK),
        'binary_sha256':sha(BINARY),'evaluator_manifest_sha256':sha(EVAL/'manifest.json')})
    print(json.dumps({'stage':'prepared','work':str(WORK),'runtime':actual}),flush=True)

def evaluate(patch, output):
    e = environment()
    result = subprocess.run([sys.executable,str(EVAL/'native_checks.py'),'tracing-1523',str(patch),str(output),
        '--calibration-root',str(CAL)],cwd=ROOT,env=e,capture_output=True)
    (ROOT/(output.name+'-console.txt')).write_bytes(result.stdout+b'\n'+result.stderr)
    if result.returncode: raise RuntimeError(result.stderr.decode(errors='replace'))
    value = read(output/'evidence.json')
    print(json.dumps({'stage':output.name, 'checks':value['checks'],'reserved_detail':value.get('reserved_detail'),
        'environment_error':value.get('environment_error')}),flush=True)
    return value

def toml(v):
    if isinstance(v,dict): return '{'+','.join(json.dumps(k)+'='+toml(x) for k,x in v.items())+'}'
    if isinstance(v,list): return '['+','.join(toml(x) for x in v)+']'
    return json.dumps(v)

def make_prompt():
    original = (ROOT/'historical-materials/L2/prompt.txt').read_text(encoding='utf-8')
    return original + f'''

## Authorized continuation, 2026-10-17
This is an informed continuation of the historical L2 implementation, already applied in this exclusive checkout. It is NOT a blind test or an independent product-effect comparison. Continue until the original complete fixed acceptance and relevant feature checks pass, or you confirm a blocker you cannot resolve. Actor and Provider must stay gpt-6.1-sol / xhigh, Masters' Nudge enabled. Do not delegate, launch another agent, commit, push, make a PR, install packages, access network, or modify historical materials, fixed tests, or evaluator. Use PowerShell and apply_patch for implementation edits. Reply in Traditional Chinese.

Read the original task/contract at {EVAL/'cases/tracing-1523'} and L2 implementation. Historical raw L1 and L2 patches, actor finals, execution reviews and Nudge attempts are at {ROOT/'historical-materials'}. Preserve L2's already passing behavior. The orchestrator reproduced L2 acceptance in {ROOT/'baseline-evaluation/evidence.json'} before launch; inspect the logs and fixed probes. All existing tests (including L2 tests and installed fixed tests) are immutable; add regressions as new files.

Two initial concerns to verify against code, NOT take as proof:
1. wrapped_custom_global_veto_rejects_every_consumer failed: a custom global Veto wrapped in with_filter(true) permits a sibling event (events=1, expected 0). L2 has FilterResult(global AND, consumers OR), but Filtered.__enabled calls result() then returns global=true. Check callsite/hint boundaries too. Global veto must remain global even through local wrappers; don't regress all-observers-reject / pure-global / hints, which L2 passes and L1 fails.
2. current_view_retains_visible_entered_root failed with observations=[["",""]] instead of [["visible","visible"]]. Parent chains do not enumerate independent roots still entered. L1 passed this case using Registry.current_span_filtered and entered-stack tracking for custom subscribers. Read its responsibility/behavior and select the smallest sound design; don't blindly concatenate L1/L2.

Keep passed boxed/reload, old spans after filter replacement, Arc, field reentrancy, Context.enabled, cleanup, max-hints and filter-cache behavior. Fixed requirement C02 requires consistent filtered current/lookup/scope/parent views and subtree AND. C03 requires global veto, independent local rejection and complete disable when no consumers accept.

The fixed suites are installed in tracing-subscriber/tests. Run offline/locked:
cargo test --offline --locked -p tracing-subscriber --features env-filter,registry,regex/unicode --tests
The fixed standalone targets are contract_tracing_contract_v2_rs, contract_tracing_hint_bounds_rs, contract_tracing_judge_concerns_rs. Run with --nocapture --test-threads=1 when investigating. Run original affected tests and feature checks (registry only, no default features, std-only, registry+env-filter) as appropriate; inspect Cargo.toml rather than assuming a nonexistent feature. CARGO_TARGET_DIR is isolated and already configured. No tool rebuild is needed.

For the unchanged canonical evaluator after a candidate is ready, export a full binary patch (including new source files) outside the checkout and run:
python "{ROOT/'continuation.py'}" evaluate --patch "<candidate.patch>" --output "{ROOT/'actor-evaluation-1'}"
Use a fresh output path per evaluation. The evaluator intentionally replaces delivery test paths with the frozen reserved surface in a separate disposable checkout; your own regression tests remain for separate verification in this checkout. Never change tests to obtain a pass.

Report the precise changes, commands and outcomes, remaining gaps, and each received Nudge's adoption/rejection with corresponding edit and verification. This is a continuation observation; do not infer causal product effectiveness. Inspect final diff and preserve all generated evidence under {ROOT}. Continue work after a failing check within scope.
'''

def launch():
    baseline = read(ROOT/'baseline-evaluation/evidence.json')
    expected = {'reserved':'pass','tracing_contract_v2.rs':'fail','tracing_hint_bounds.rs':'pass','tracing_judge_concerns.rs':'fail'}
    assert baseline['checks']==expected, baseline
    assert not (RUN/'actor-events.jsonl').exists(), 'One new Actor per explicit launch'
    hooks=[]
    def resolve(v):
        if isinstance(v,dict): return {k:resolve(x) for k,x in v.items()}
        if isinstance(v,list): return [resolve(x) for x in v]
        return v.replace('${PLUGIN_ROOT}',PACKAGE.as_posix()) if isinstance(v,str) else v
    for k,v in read(PACKAGE/'.mcp.json')['mcpServers'].items(): hooks+=['-c',f'mcp_servers.{k}={toml(resolve(v))}']
    for k,v in read(PACKAGE/'hooks/hooks.json')['hooks'].items(): hooks+=['-c',f'hooks.{k}={toml(v)}']
    prompt = make_prompt()
    (RUN/'prompt.txt').write_text(prompt,encoding='utf-8')
    args=[str(BINARY),'-c','project_doc_max_bytes=0','-c','features.multi_agent=false','-c','model_reasoning_effort="xhigh"',
        '--enable','hooks','--disable','plugins',*hooks,'exec','--ignore-user-config','--ignore-rules',
        '--dangerously-bypass-hook-trust','--skip-git-repo-check','--ephemeral','--json','-s','danger-full-access',
        '-m','gpt-6.1-sol','-C',str(WORK),'-o',str(RUN/'actor-final.txt'),'-']
    e=environment()
    save(RUN/'launch.json',{'command':args,'hooks':True,'actor_model':'gpt-6.1-sol','actor_reasoning':'xhigh',
        'provider_model':'gpt-6.1-sol','provider_reasoning':'xhigh','binary_sha256':sha(BINARY),
        'prompt_sha256':sha(RUN/'prompt.txt'),'base_commit':BASE,'timeout_seconds':None,
        'environment':{k:v for k,v in e.items() if k.startswith(('MASTERS_NUDGE','CARGO_')) or k in ('PLUGIN_ROOT','TEMP','TMP','RUSTFLAGS','PATH')}})
    observer_out=(RUN/'observer-stdout.txt').open('w',encoding='utf-8')
    observer_err=(RUN/'observer-stderr.txt').open('w',encoding='utf-8')
    observer=subprocess.Popen(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'observe-processes.ps1'),
        '-ExperimentRoot',str(ROOT)],cwd=ROOT,stdout=observer_out,stderr=observer_err,creationflags=subprocess.CREATE_NO_WINDOW)
    for _ in range(50):
        if (RUN/'observer-ready').exists(): break
        if observer.poll() is not None: raise RuntimeError('Process observer failed; inspect observer-stderr.txt')
        time.sleep(0.1)
    else: raise RuntimeError('Process observer not ready')
    started=time.monotonic()
    with (RUN/'actor-events.jsonl').open('w',encoding='utf-8') as out, (RUN/'actor-stderr.txt').open('w',encoding='utf-8') as err:
        p=subprocess.Popen(args,cwd=WORK,env=e,stdin=subprocess.PIPE,stdout=out,stderr=err,
            text=True,encoding='utf-8',creationflags=subprocess.CREATE_NO_WINDOW)
        save(RUN/'running.json',{'pid':p.pid,'started_utc':now()})
        print(json.dumps({'stage':'actor_started','pid':p.pid}),flush=True)
        p.communicate(prompt)
    (RUN/'observer-stop').write_text(now(),encoding='utf-8')
    observer.wait(timeout=10)
    observer_out.close();observer_err.close()
    usage={}
    for line in (RUN/'actor-events.jsonl').read_text(encoding='utf-8').splitlines():
        try: event=json.loads(line)
        except ValueError: continue
        if event.get('type')=='turn.completed': usage=event.get('usage',{})
    export_patch(ROOT/'final.patch')
    attempts=[]
    if (DATA/'feedback.sqlite3').exists():
        with sqlite3.connect(DATA/'feedback.sqlite3') as con:
            con.row_factory=sqlite3.Row
            for r in con.execute('SELECT * FROM attempts ORDER BY started'):
                r=dict(r);r['detail']=json.loads(r['detail']) if r.get('detail') else {};attempts.append(r)
    save(RUN/'provider-attempts.json',attempts)
    save(RUN/'result.json',{'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-started,3),
        'completed_utc':now(),'actor_usage':usage,'provider_usage':{k:sum(int(x.get('detail',{}).get('usage',{}).get(k) or 0) for x in attempts)
        for k in ('input_tokens','cached_input_tokens','output_tokens','reasoning_output_tokens')},'attempt_count':len(attempts)})
    print(json.dumps({'stage':'actor_finished','exit_code':p.returncode}),flush=True)

def export_patch(path):
    run(['git','add','-N','.'],WORK)
    fixed = re.findall(r'^diff --git a/(.*?) b/.*$',(EVAL/'cases/tracing-1523/test.patch').read_text(),re.M)
    fixed += ['Cargo.lock','tracing-subscriber/tests/benchmark_public_layer_tests.rs']
    fixed += ['tracing-subscriber/tests/contract_'+n.replace('.','_')+'.rs' for n in
        ('tracing_contract_v2.rs','tracing_hint_bounds.rs','tracing_judge_concerns.rs')]
    exclusions=[':(exclude)'+n for n in fixed]
    result=subprocess.run(['git','diff','--binary',BASE,'--','.',*exclusions],cwd=WORK,capture_output=True,check=True)
    Path(path).write_bytes(result.stdout)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','baseline','launch','evaluate','export'])
    p.add_argument('--patch',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args()
    if a.action=='prepare': prepare()
    elif a.action=='baseline': evaluate(ROOT/'historical-materials/L2/final.patch',ROOT/'baseline-evaluation')
    elif a.action=='launch': launch()
    elif a.action=='evaluate': evaluate(a.patch.resolve(),a.output.resolve())
    elif a.action=='export': export_patch(a.output or ROOT/'final.patch')
