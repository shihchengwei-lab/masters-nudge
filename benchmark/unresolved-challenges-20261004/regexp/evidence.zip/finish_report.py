"""Publish results only after an explicit semantic execution and code review."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
import pipeline

ROOT = Path(__file__).resolve().parent
plan = pipeline.read(ROOT / 'plan.json')
summary = pipeline.read(ROOT / 'execution-summary.json')
assert summary['completed'] == summary['expected'] == 2
code_review = pipeline.read(ROOT / 'code-review.json')
assert code_review['method'] and code_review['new_model_judge_calls'] == 0
assert set(code_review['trials']) == set(plan['new_arms'])
rows = []
fingerprints = {}
for arm in plan['new_arms']:
    folder = ROOT / 'runs' / plan['case'] / arm
    result = pipeline.read(folder / 'result.json')
    launch = pipeline.read(folder / 'launch.json')
    audit = pipeline.read(folder / 'execution-evidence.json')
    execution = pipeline.read(folder / 'execution-review.json')
    fixed = pipeline.read(folder / 'fixed-checks.json')
    assert launch['model'] == launch['provider_model'] == 'gpt-6-astra'
    assert launch['reasoning'] == launch['provider_reasoning'] == 'max'
    assert launch['timeout_seconds'] is None
    assert result['actor_model'] == result['provider_model'] == 'gpt-6-astra'
    assert result['actor_reasoning'] == result['provider_reasoning'] == 'max'
    assert execution['execution_evidence_sha256'] == pipeline.sha(folder / 'execution-evidence.json')
    assert audit['transcript_sha256'] == pipeline.sha(folder / 'actor-events.jsonl')
    assert audit['patch_sha256'] == result['patch_sha256'] == fixed['patch_sha256'] == execution['patch_sha256'] == pipeline.sha(folder / 'final.patch')
    assert audit['task_prompt_sha256'] == plan['prompt_sha256']
    assert execution['status'] in ('pass', 'fail', 'environment_error')
    assert execution['reason'] and execution['evidence']
    fixed['execution_review'] = execution
    score = pipeline.evaluate.score(plan['case'], folder / 'final.patch', fixed)
    pipeline.save(folder / 'score.json', score)
    attempts = pipeline.read(folder / 'provider-attempts.json')
    actor_usage = {k: result['actor_usage'].get(k) for k in ('input_tokens', 'cached_input_tokens', 'output_tokens')}
    provider_usage = {k: sum(int(a.get('detail', {}).get('usage', {}).get(k) or 0) for a in attempts)
                      if all(k in a.get('detail', {}).get('usage', {}) for a in attempts) else None
                      for k in ('input_tokens', 'cached_input_tokens', 'output_tokens')}
    rows.append({'arm': arm, 'task_completed': score['task_completed'],
                 'functional_status': score['status'], 'execution_status': execution['status'],
                 'failed_checks': score['failed_checks'], 'fixed_checks': fixed['checks'],
                 'actor_seconds': result['actor_elapsed_seconds'],
                 'actor_usage': actor_usage, 'provider_usage': provider_usage,
                 'provider_attempts': len(attempts), 'provider_feedback': result['provider_feedback_count'],
                 'provider_delivered': result['provider_delivered_count'],
                 'provider_silence': result['provider_silence_count'],
                 'provider_faults': result['provider_fault_count'], 'execution_fault': result['execution_fault'],
                 'code_review': code_review['trials'][arm]})
    for name in ('result.json', 'launch.json', 'actor-events.jsonl', 'actor-final.txt', 'final.patch',
                 'provider-attempts.json', 'fixed-checks.json', 'execution-evidence.json',
                 'execution-review.json', 'score.json'):
        if (folder / name).exists():
            fingerprints[(folder / name).relative_to(ROOT).as_posix()] = pipeline.sha(folder / name)
public = pipeline.REPO / 'benchmark/model-comparison-20261004'
assert pipeline.sha(public / 'evidence.zip') == plan['original_seven_arm_evidence_sha256']
assert pipeline.sha(public / 'results-summary.json') == plan['original_seven_arm_summary_sha256']
assert pipeline.sha(pipeline.SOURCE / 'results-summary.json') == plan['source_study_summary_sha256']
assert pipeline.read(ROOT / 'restoration-confirmed.json')['original_case_restored']
assert pipeline.state(pipeline.runner.safe_work(plan['case'])) == pipeline.read(ROOT / 'worktree-backups' / plan['case'] / 'original-state.json')
assert pipeline.runner.package_hashes() == plan['package_hashes']
assert pipeline.evaluate.verify() == plan['evaluator_sha256']
index = Path(pipeline.runner.git(pipeline.runner.safe_work(plan['case']), 'rev-parse', '--path-format=absolute', '--git-path', 'index').strip())
original_index = ROOT / 'worktree-backups' / plan['case'] / 'index'
for args in (['ls-files', '--stage', '-z'], ['ls-files', '-v', '-z'], ['diff', '--cached', '--binary', 'HEAD']):
    current = subprocess.check_output(['git', *args], cwd=pipeline.runner.safe_work(plan['case']), env=dict(os.environ, GIT_INDEX_FILE=str(index)))
    original = subprocess.check_output(['git', *args], cwd=pipeline.runner.safe_work(plan['case']), env=dict(os.environ, GIT_INDEX_FILE=str(original_index)))
    assert current == original, args
# Git can refresh index stat/cache bytes while reading differences. Preserve
# those bytes and restore the original only after the semantic Git checks.
shutil.copy2(index, ROOT / 'worktree-backups' / plan['case'] / 'index-after-semantic-checks')
shutil.copy2(original_index, index)
assert pipeline.sha(index) == pipeline.sha(original_index)
actual_launches = pipeline.read(ROOT / 'actual-model-launches.json')
assert sum(x['role'] == 'Actor' for x in actual_launches) == 2
assert sum(x['role'] == 'Provider' for x in actual_launches) == sum(r['provider_attempts'] for r in rows)
assert all('-m gpt-6-astra' in x['command'] and 'model_reasoning_effort=' in x['command'] and 'max' in x['command'] for x in actual_launches)
pipeline.save(ROOT / 'results-summary.json', {'case': plan['case'], 'trials': rows,
              'completed': sum(r['task_completed'] is True for r in rows), 'expected': 2,
              'baseline_completed': 0, 'baseline_attempts': 14,
              'actor_model': 'gpt-6-astra', 'actor_reasoning': 'max',
              'provider_model': 'gpt-6-astra', 'provider_reasoning': 'max', 'actor_deadline_seconds': None,
              'scope': 'Exploration; not comparable deadline conditions; original seven arms unchanged'})
lines = ['# Astra max 雙模型：Regexp 兩次挑戰結果', '',
         f'日期：{datetime.now(timezone.utc).astimezone().date()}。Actor、Provider 都是 GPT-6 Astra max；兩次從同一基底獨立開始，Actor 不限時。', '',
         f'**完整交付：{sum(r["task_completed"] is True for r in rows)}/2。** 原七臂此題為0/14；本輪同時改模型、深度與解題時限，不將差異單獨歸因於工具或模型，亦不併入七臂排名。', '',
         '| 次數 | 完整交付 | 功能／執行契約 | Actor 分鐘（含 Provider 等待） | 提醒／送達／故障 |',
         '|---|---|---|---:|---|']
for r in rows:
    lines.append(f'| {r["arm"]} | {r["task_completed"]} | {r["functional_status"]}／{r["execution_status"]} | {r["actor_seconds"]/60:.2f} | {r["provider_feedback"]}／{r["provider_delivered"]}／{r["provider_faults"]} |')
lines += ['', '## 固定驗收、提醒與程式結構', '']
for r in rows:
    lines += [f'### {r["arm"]}', '',
              '固定檢查：' + json.dumps(r['fixed_checks'], ensure_ascii=False) + '。', '',
              '執行契約：' + pipeline.read(ROOT / 'runs' / plan['case'] / r['arm'] / 'execution-review.json')['reason'], '',
              '程式品質：' + r['code_review']['quality'], '',
              r['code_review']['structure'], '',
              *['- ' + finding for finding in r['code_review']['findings']], '',
              '提醒採納：' + r['code_review']['adoption']['classification'] + '。' + r['code_review']['adoption']['explanation'], '',
              f'來源：[Actor 說明](runs/{plan["case"]}/{r["arm"]}/actor-final.txt)、[原始修改](runs/{plan["case"]}/{r["arm"]}/final.patch)、[提醒](runs/{plan["case"]}/{r["arm"]}/provider-attempts.json)、[執行覆核](runs/{plan["case"]}/{r["arm"]}/execution-review.json)。', '']
lines += ['## 用量與方法', '',
          '| 次數 | Actor＋Provider 輸入（含快取） | 快取輸入 | 未快取輸入 | 輸出 |',
          '|---|---:|---:|---:|---:|']
for r in rows:
    totals = {k: r['actor_usage'][k] + r['provider_usage'][k] if r['actor_usage'][k] is not None and r['provider_usage'][k] is not None else None for k in ('input_tokens', 'cached_input_tokens', 'output_tokens')}
    uncached = totals['input_tokens'] - totals['cached_input_tokens'] if totals['input_tokens'] is not None and totals['cached_input_tokens'] is not None else None
    lines.append(f'| {r["arm"]} | {totals["input_tokens"]:,} | {totals["cached_input_tokens"]:,} | {uncached:,} | {totals["output_tokens"]:,} |' if all(v is not None for v in totals.values()) else f'| {r["arm"]} | {totals["input_tokens"]} | {totals["cached_input_tokens"]} | {uncached} | {totals["output_tokens"]} |')
lines += ['',
          '以下為各次原始 Token 用量；缺值保留 null，Provider 呼叫不存在時才是0。Actor 的輸入包含 Provider 送達後續上下文；Provider 模型本身另記，不能只看 Actor 費用。reasoning output 是 output 的子集，不重複加總。', '',
          '```json', json.dumps([{k: r[k] for k in ('arm', 'actor_usage', 'provider_usage')} for r in rows], ensure_ascii=False, indent=2), '```', '',
          '本輪執行契約與程式碼由 Codex 閱讀原始行動及程式作語意覆核，已知組別；沒有新增匿名品味評審票。原七臂沒有合格的 Regexp 答案，因此不作與失敗交付的品味勝負排名。', '',
          '條件、harness、傳輸等待與來源見 [MATERIALS](MATERIALS.zh-TW.md)、[計畫](plan.json)；完整數據見 [results-summary.json](results-summary.json)，檔案指紋與原材料保全見 [final-integrity.json](final-integrity.json)。']
(ROOT / 'REPORT.zh-TW.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
for name in ('plan.json', 'results-summary.json', 'REPORT.zh-TW.md', 'code-review.json', 'restoration-confirmed.json', 'actual-model-launches.json', 'record_semantic_review.py', 'finish_report.py', 'export_review.py', 'review-finalization-log.json', 'restore_index_metadata.py'):
    fingerprints[name] = pipeline.sha(ROOT / name)
pipeline.save(ROOT / 'final-integrity.json', {'verified': True, 'results': 2,
              'original_case_restored': True, 'original_seven_arm_evidence_unchanged': True,
              'original_index_restored': True, 'actual_model_launches_verified': True,
              'actor_deadline': None, 'actor_and_provider': 'gpt-6-astra max', 'fingerprints': fingerprints})
pipeline.save(ROOT / 'pipeline-status.json', {'status': 'complete', 'results': 2,
              'completed': sum(r['task_completed'] is True for r in rows), 'report': 'REPORT.zh-TW.md'})
print(json.dumps({'complete': True, 'results': 2, 'passed': sum(r['task_completed'] is True for r in rows)}, ensure_ascii=False))
