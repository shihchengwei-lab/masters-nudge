$taskRoot = $PSScriptRoot
$taskPipeline = Get-Content -LiteralPath (Join-Path $taskRoot 'pipeline-process.json') -Raw | ConvertFrom-Json
$taskObserved = @{}
while ($true) {
    $taskOwner = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $taskPipeline.pid)
    if (-not $taskOwner -or $taskOwner.CreationDate.ToUniversalTime().Ticks -ne ([datetime]$taskPipeline.creation_date).ToUniversalTime().Ticks) { break }
    Get-CimInstance Win32_Process -Filter "Name = 'codex.exe'" | ForEach-Object {
        $taskCommand = $_.CommandLine
        if ($taskCommand -and ($taskCommand.Contains($taskRoot) -or $taskCommand.Contains($taskRoot.Replace('\','/')))) {
            $taskKey = $_.ProcessId.ToString() + '/' + $_.CreationDate.ToUniversalTime().ToString('o')
            if (-not $taskObserved.ContainsKey($taskKey)) {
                $taskObserved[$taskKey] = [ordered]@{pid=$_.ProcessId; parent_pid=$_.ParentProcessId; creation_date=$_.CreationDate.ToUniversalTime().ToString('o'); command=$taskCommand; role=$(if ($taskCommand -like '*actor-final.txt*') {'Actor'} else {'Provider'})}
                @($taskObserved.Values) | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskRoot 'actual-model-launches.json') -Encoding utf8
            }
        }
    }
    Start-Sleep -Seconds 15
}
