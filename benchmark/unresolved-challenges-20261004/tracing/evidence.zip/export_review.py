"""Export actual actions and feedback for semantic review; never approve automatically."""
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
import pipeline

ROOT = Path(__file__).resolve().parent
plan = pipeline.read(ROOT / 'plan.json')
for arm in plan['new_arms']:
    folder = ROOT / 'runs' / plan['case'] / arm
    if not (folder / 'result.json').exists():
        continue
    result = pipeline.read(folder / 'result.json')
    commands, changes, other, errors = [], [], [], []
    for number, line in enumerate((folder / 'actor-events.jsonl').read_text(encoding='utf-8').splitlines(), 1):
        try:
            event = json.loads(line)
        except ValueError:
            errors.append({'line': number, 'invalid_json': line})
            continue
        if event.get('type') in ('error', 'turn.failed'):
            errors.append({'line': number, 'event': event})
        if event.get('type') != 'item.completed':
            continue
        item = event.get('item', {})
        kind = item.get('type')
        if kind == 'command_execution':
            commands.append({'line': number, 'command': item.get('command'), 'exit_code': item.get('exit_code')})
        elif kind == 'file_change':
            changes.append({'line': number, 'status': item.get('status'), 'changes': item.get('changes')})
        elif kind not in ('agent_message', 'reasoning', 'error', None):
            other.append({'line': number, 'item': item})
    record = {'case': plan['case'], 'arm': arm, 'commands': commands,
              'file_changes': changes, 'other_tools': other, 'errors': errors,
              'existing_tests_changed': result['tests_modified'],
              'patch_paths': re.findall(r'^\+\+\+ b/(.*)$', (folder / 'final.patch').read_text(encoding='utf-8'), re.M),
              'transcript_sha256': pipeline.sha(folder / 'actor-events.jsonl'),
              'patch_sha256': pipeline.sha(folder / 'final.patch'),
              'launch': pipeline.read(folder / 'launch.json'),
              'task_prompt_sha256': pipeline.runner.textsha((folder / 'prompt.txt').read_text(encoding='utf-8')),
              'actor_exit': result['actor_exit'], 'actor_seconds': result['actor_elapsed_seconds'],
              'actor_deadline_seconds': None}
    pipeline.save(folder / 'execution-evidence.json', record)
    text = [f'# {plan["case"]}/{arm} 執行覆核材料', '',
            '依原任務審查執行行為；本輪沒有30分鐘截止條件，不能以時間判失敗。', '',
            '## 命令紀錄', '']
    text += [f'L{c["line"]} exit={c["exit_code"]} {c["command"]}' for c in commands]
    text += ['', '## 檔案改動', json.dumps(changes, ensure_ascii=False, indent=2), '',
             '## 其他工具', json.dumps(other, ensure_ascii=False, indent=2), '',
             '## 錯誤', json.dumps(errors, ensure_ascii=False, indent=2)]
    (folder / 'execution-evidence.zh-TW.md').write_text('\n'.join(text) + '\n', encoding='utf-8')
    print(json.dumps({'arm': arm, 'commands': len(commands), 'changes': len(changes), 'exported': str(folder)}, ensure_ascii=False))
