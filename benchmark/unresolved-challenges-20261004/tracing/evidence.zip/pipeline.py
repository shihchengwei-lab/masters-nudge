"""Run two independent Astra max trials; keep answers and restore the shared checkout."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = Path('<USER_HOME>/Desktop/GH_repos/masters-nudge')
SOURCE = Path('<RESEARCH_E>/masters-nudge-benchmark/sol61-i-xhigh-sol-xhigh-provider-12case-20261004')
CASE = 'tracing-1523'
ARMS = ['L1', 'L2']
sys.path.insert(0, str(ROOT))
import actor_runner as runner
sys.path.insert(0, str(ROOT / 'frozen-evaluation'))
import evaluate
import native_checks


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    runner.save(path, value)


def emit(value):
    print(json.dumps(value, ensure_ascii=False), flush=True)


def state(work):
    patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=work)
    names = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=work).decode().split('\0')
    return {'head': runner.git(work, 'rev-parse', 'HEAD').strip(),
            'patch_sha256': hashlib.sha256(patch).hexdigest(),
            'untracked': {name: sha(work / name) for name in names if name and (work / name).is_file()}}


def prepare():
    source = read(SOURCE / 'plan.json')
    meta = dict(source['cases'][CASE])
    prompt = (ROOT / 'prompt.txt').read_text(encoding='utf-8')
    prompt_hash = runner.textsha(prompt)
    assert prompt_hash == meta['I_prompt_sha256']
    meta.update(A_prompt_sha256=prompt_hash, B_prompt_sha256=prompt_hash, new_order=ARMS)
    binary = Path(source['codex_binary'])
    assert sha(binary) == source['codex_binary_sha256']
    version = subprocess.check_output([str(binary), '--version'], text=True).strip()
    assert version == 'codex-cli 0.159.2'
    cache = read(Path(os.environ['USERPROFILE']) / '.codex/models_cache.json')
    astra = next(m for m in cache['models'] if m['slug'] == 'gpt-6-astra')
    assert 'max' in {m['effort'] for m in astra['supported_reasoning_levels']}
    before = {p.relative_to(SOURCE / 'frozen-plugin').as_posix(): sha(p)
              for p in (SOURCE / 'frozen-plugin').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
    after = runner.package_hashes()
    assert before.keys() == after.keys()
    assert [name for name in before if before[name] != after[name]] == ['masters_nudge/runtime.py']
    assert (SOURCE / 'frozen-plugin/masters_nudge/runtime.py').read_text(encoding='utf-8').replace(
        'PROVIDER_REASONING_EFFORT = "xhigh"', 'PROVIDER_REASONING_EFFORT = "max"') == (
        ROOT / 'frozen-plugin/masters_nudge/runtime.py').read_text(encoding='utf-8')
    work = runner.safe_work(CASE)
    assert runner.git(work, 'rev-parse', 'HEAD').strip() == meta['base_commit']
    expected_env = read(ROOT / 'frozen-evaluation/environment.json')
    versions = {name: subprocess.check_output([name, '--version'], text=True).strip() for name in ('cargo', 'rustc')}
    for name in versions:
        assert versions[name] == expected_env[name], (name, versions[name], expected_env[name])
    assert (Path(os.environ['USERPROFILE']) / '.cargo/registry').is_dir()
    assert (runner.CAL / 'cargo-target' / CASE).is_dir()
    assert (work / 'Cargo.lock').is_file()
    evaluator_hash = evaluate.verify()
    public = REPO / 'benchmark/model-comparison-20261004'
    old = read(public / 'results-summary.json')
    baseline = [{'arm': d['arm'], 'completed': d['completed']} for d in old['deliveries'] if d['case'] == CASE]
    assert len(baseline) == 14 and not any(d['completed'] for d in baseline)
    plan = {'name': 'Astra max Actor + Astra max Provider; Tracing x2; no Actor deadline',
            'created_utc': datetime.now(timezone.utc).isoformat(),
            'actor_model': 'gpt-6-astra', 'actor_reasoning': 'max',
            'provider_model': 'gpt-6-astra', 'provider_reasoning': 'max',
            'actor_wall_timeout_seconds': None, 'expected_deliveries': 2, 'workers': 1,
            'provider_timeout_seconds': 1200, 'hook_timeout_seconds': 1320,
            'feedback_limit': 3, 'silence_limit': 2,
            'case': CASE, 'new_arms': ARMS, 'cases': {CASE: meta},
            'codex_binary': str(binary), 'codex_binary_sha256': sha(binary), 'codex_cli_version': version,
            'package_hashes': after, 'evaluator_sha256': evaluator_hash,
            'actor_runner_sha256': sha(ROOT / 'actor_runner.py'), 'pipeline_sha256': sha(__file__),
            'prompt_sha256': prompt_hash, 'product_commit': runner.git(REPO, 'rev-parse', 'HEAD').strip(),
            'original_seven_arm_evidence_sha256': sha(public / 'evidence.zip'),
            'original_seven_arm_summary_sha256': sha(public / 'results-summary.json'),
            'source_study_summary_sha256': sha(SOURCE / 'results-summary.json'),
            'baseline_completion': baseline,
            'method': 'Fresh base for each attempt. Same task, prompt, dependencies, frozen tool and evaluator. Only model/effort and Actor deadline change. Not a new comparable seven-arm score.',
            'retry_policy': 'Never redraw generated answers or functional failures. Only zero-change, zero-Provider model-capacity/transport failures may be archived and resumed with adjusted backoff.',
            'execution_review': 'Review original task and recorded actions after both attempts; no 30-minute criterion.',
            'cost_scope': 'Record actual Actor wall time (including Provider waits), Actor and Provider tokens; missing usage stays missing.'}
    if (ROOT / 'plan.json').exists():
        existing = read(ROOT / 'plan.json')
        for key in ('package_hashes', 'evaluator_sha256', 'actor_runner_sha256', 'pipeline_sha256',
                    'prompt_sha256', 'codex_binary_sha256', 'original_seven_arm_evidence_sha256',
                    'original_seven_arm_summary_sha256', 'source_study_summary_sha256'):
            assert existing[key] == plan[key], key
        plan = existing
    else:
        save(ROOT / 'plan.json', plan)
    runner.resolve_codex_bin = lambda: str(binary)
    runner.prompts = lambda cid: (prompt, prompt)
    runner.initialize = lambda: plan
    save(ROOT / 'preflight.json', {'status': 'pass', 'case': CASE, 'Astra_max_supported': True,
                                  'actor_timeout': None, 'frozen_evaluator': evaluator_hash,
                                  'CLI': version, 'rust_versions': versions, 'original_lock_sha256': sha(work / 'Cargo.lock'),
                                  'only_plugin_change': 'Provider effort xhigh -> max'})
    return plan


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    plan = prepare()
    if len(sys.argv) > 1 and sys.argv[1] == 'prepare':
        emit({'stage': 'prepared', 'case': CASE, 'actor': 'Astra max', 'provider': 'Astra max', 'trials': 2, 'actor_deadline': None})
        return
    assert not (ROOT / 'execution-summary.json').exists(), 'Recorded answers must not be rerun.'
    save(ROOT / 'orchestrator.json', {'pid': os.getpid(), 'started_utc': datetime.now(timezone.utc).isoformat()})
    save(ROOT / 'pipeline-status.json', {'status': 'running', 'stage': 'actors', 'case': CASE})
    work = runner.safe_work(CASE)
    backup = ROOT / 'worktree-backups' / CASE
    backup.mkdir(parents=True, exist_ok=False)
    original = state(work)
    save(backup / 'original-state.json', original)
    index = Path(runner.git(work, 'rev-parse', '--path-format=absolute', '--git-path', 'index').strip())
    shutil.copy2(index, backup / 'index')
    runner.git(work, 'add', '-N', '.')
    patch = backup / 'original.patch'
    patch.write_text(runner.git(work, 'diff', '--binary', 'HEAD'), encoding='utf-8', newline='\n')
    results = []
    try:
        for arm in ARMS:
            result = runner.run_one(CASE, arm, plan)
            results.append(result)
            save(ROOT / 'pipeline-status.json', {'status': 'running', 'stage': 'fixed-checks', 'arm': arm})
            artifact = ROOT / 'runs' / CASE / arm
            if result['verification_error'] and not result['tests_modified']:
                raise RuntimeError('Verification infrastructure: ' + result['verification_error'])
            fixed = native_checks.execute(CASE, artifact / 'final.patch', ROOT / 'evaluation' / CASE / arm, runner.CAL)
            save(artifact / 'fixed-checks.json', fixed)
            emit({'stage': 'fixed-checks', 'arm': arm, 'checks': fixed['checks']})
            save(ROOT / 'pipeline-status.json', {'status': 'running', 'stage': 'actors', 'finished': len(results)})
        save(ROOT / 'execution-summary.json', {'expected': 2, 'completed': len(results), 'case': CASE,
                                               'results': results, 'pending': 'Execution contract and code review'})
        save(ROOT / 'pipeline-status.json', {'status': 'awaiting_review', 'stage': 'execution-and-code-review', 'results': 2})
    except Exception as exc:
        save(ROOT / 'pipeline-status.json', {'status': 'needs_repair', 'stage': 'execution', 'error': repr(exc), 'completed': len(results)})
        raise
    finally:
        runner.reset(CASE, plan['cases'][CASE]['base_commit'])
        runner.apply(work, patch)
        shutil.copy2(backup / 'index', index)
        restored = state(work)
        save(backup / 'restored-state.json', restored)
        assert restored == original, 'Shared checkout restoration failed'
        public = REPO / 'benchmark/model-comparison-20261004'
        assert sha(public / 'evidence.zip') == plan['original_seven_arm_evidence_sha256']
        assert sha(public / 'results-summary.json') == plan['original_seven_arm_summary_sha256']
        assert sha(SOURCE / 'results-summary.json') == plan['source_study_summary_sha256']
        save(ROOT / 'restoration-confirmed.json', {'original_case_restored': True, 'original_seven_arm_evidence_unchanged': True})
        emit({'stage': 'restored', 'original_state_matches': True})


if __name__ == '__main__':
    main()
