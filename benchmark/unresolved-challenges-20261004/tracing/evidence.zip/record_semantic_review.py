from pathlib import Path
import json, hashlib
ROOT=Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def source(folder, name, needles):
 lines=(folder/name).read_text(encoding='utf-8-sig').splitlines()
 return {'file':str(folder/name),'line_anchors':{s:[n for n,l in enumerate(lines,1) if s in l] for s in needles}}

reasons={
'L1':'執行契約通過：以 apply_patch 修改產品原始碼與新增測試；完整命令未見提交、套件安裝、歷史變更、網路或委派。既有測試未修改，指定 cargo 測試、功能開關檢查與最終差異檢視均完成。Actor 不限時，31.32 分鐘不構成失敗；功能契約另由固定驗收判定為失敗。',
'L2':'執行契約通過：以 apply_patch 修改產品原始碼與新增測試，並刪除自身暫存驗證日誌；完整命令未見提交、套件安裝、歷史變更、網路或委派。既有測試未修改，指定 cargo 測試及後續受影響測試、功能開關與最終差異檢視完成。Actor 不限時，53.63 分鐘不構成失敗；功能契約另由固定驗收判定為失敗。'}

reviews={
'L1':{
'quality':'有實質行為修補與回歸測試，但尚非完整、可靠的交付；不能因新增抽象與測試量就評為高品味。固定補充探針 6/10 通過，兩份都另通過保留的 148 項測試。',
'structure':'Context、SpanRef、Scope 攜帶累積篩選視圖，且 current 使用已進入 span 堆疊，這些結構直接對應不同的關係需求。另一方面，__is_filtered 的單一布林分類不足以區分全域門檻與實際接收者；combine_enabled／combine_hint 的分支規則仍把純全域篩選器當接收者。快照、弱世代、識別值轉移和額外 entered stack 各自有理由，但留下跨層同步責任，並未讓錯誤狀態難以表達。',
'findings':[
'全域 LevelFilter 允許、所有實際觀察者拒絕時仍啟用 span 且計算欄位：all_observers_reject_under_global_filter 的 field_evaluations=2、span_disabled=false；pure_global_filter_does_not_enable_rejected_items 的 fields=1、span_disabled=false。',
'INFO 接收者外加 TRACE 全域門檻，max_level_hint 回傳 TRACE，應為 INFO；全域門檻被錯算為額外接收者。',
'自訂 Veto 被 with_filter(true) 包裝後，其拒絕不能阻止兄弟接收事件；wrapped_custom_global_veto_rejects_every_consumer 的 events=1，應為0。Filtered.enabled 將內層拒絕壓為分支拒絕，再被兄弟的 OR 接收蓋過。',
'current_view_retains_visible_entered_root 通過：仍進入中的可見 root 不會因另一個無親屬關係的隱藏 root 被漏掉。快取重載、Arc、欄位重入與 Context.enabled 補查亦通過。'],
'adoption':{'classification':'三次提醒均有實際結構採納；不等於完整契約已解決',
'explanation':'提醒1要求 Context→SpanRef→Scope 累積視圖與跳過拒絕祖先，最終實作與 nested_filters 測試可見此結構；提醒2要求每次發送獨立決策快照以保護重入，最終 FilterState、EnabledGuard 與 snapshot 及 reentrant_delivery 測試相符；提醒3要求 entered stack 而非 parent chain 求 current，最終 Registry.current_span_filtered／自訂 subscriber ThreadLocalSpanStack 與兩個不同 root 測試相符，固定 current-view 探針也通過。Actor L37、L41、L63-L82 可見對應工作。但 Actor 本已計畫其中部分需求，不能將全部成果因果歸功於 Provider。'}},
'L2':{
'quality':'相較第一份，固定補充探針缺口較少（8/10 通過），但仍有核心語意錯誤，尚不宜判為完整或高品味交付。兩次是獨立嘗試，通過數差異不是模型能力的統計結論。',
'structure':'FilterResult 明確分開 global 與 consumers，分別 AND 與 OR，比單一 filtered 布林能更精確表達合併責任；Option::None 的空接收者也有直接表示。但 Filtered.__enabled 又對內層結果呼叫 result()，把全域拒絕與分支拒絕壓成同一布林，再回傳 global=true，所以核心區分未跨越包裝邊界。LevelFilter／EnvFilter 特例、四個 TLS 通道、owner 型別／位址與 revision 快取仍需共同維持一致；新增層次本身不能證明減少了完整流程的維護責任。',
'findings':[
'與第一份相同，自訂全域 Veto 經 with_filter 包裝後被降為分支拒絕，兄弟仍收到一筆事件；wrapped_custom_global_veto_rejects_every_consumer 的 events=1，應為0。',
'Context.current_span 只沿目前 span 的父鏈找可見祖先，不能取代 entered stack。另一個隱藏 root 已進入時，仍進入中的可見 root 被漏掉：current_view_retains_visible_entered_root observations=[["",""]]，應為 [["visible","visible"]]。',
'全部實際接收者拒絕時的欄位停用、純全域門檻與 max-level-hint 均通過；相較第一份改善了這些具體情況。',
'boxed/reload、同篩選器重載保留舊 span 隱藏、Arc、欄位重入與 Context.enabled 補查通過；自身測試只檢查 current 的親屬鏈案例，漏掉兩個獨立 entered root。'],
'adoption':{'classification':'三次提醒均有實際採納；仍漏掉包裝邊界與 current 的關係語意',
'explanation':'提醒1要求公開 registry 下的 Filter、函式篩選器與 with_filter，最終公開匯出與建構 API 已接通；提醒2要求快取世代與 pending 決策綁定，最終 revision、Weak 世代及 pending 檢查、reload 首筆事件與整個 Filtered 替換回歸測試對應；提醒3要求 Option::None 為空消費者，最終 false／never／OFF 三組 overrides 與 absent_layers 測試直接採納，global AND／consumer OR 也被明確建模。Actor L46、L59 回報對應修補。這些建議部分與原任務／Actor 既有規劃重疊，採納證據不支持單一因果歸因。'}}}

for arm in ['L1','L2']:
 folder=ROOT/'runs'/'tracing-1523'/arm
 audit=json.loads((folder/'execution-evidence.json').read_text(encoding='utf-8-sig'))
 assert not audit['existing_tests_changed'] and not audit['other_tools'] and not audit['errors']
 lines=[114,116,119,121] if arm=='L1' else [134,152,158,159,161,163,165,167,169,171,173]
 evidence=[{'file':str(folder/'actor-events.jsonl'),'event_lines':lines,'task_clause':'使用 apply_patch；不可修改既有測試；完成 cargo test -p tracing-subscriber --features env-filter,registry,regex/unicode --tests 及最終差異檢視；禁止提交、安裝、Git 歷史、網路及委派。','assessment':'閱讀完整命令與修改事件，核對最後驗證及差異；新增測試屬允許範圍。'},
 {'file':str(folder/'execution-evidence.json'),'task_clause':'Actor 整體解題不限時；保留原答案，不重抽。','assessment':'actor_deadline_seconds=null；現有答案指紋與固定驗收一致。'},
 {'file':str(folder/'result.json'),'task_clause':'既有測試保持不變並執行指定測試。','assessment':'tests_modified=[]；保留測試 148 通過、0失敗；actor_exit=0、execution_fault空白。'}]
 save(folder/'execution-review.json',{'status':'pass','reason':reasons[arm],'evidence':evidence,'patch_sha256':sha(folder/'final.patch'),'execution_evidence_sha256':sha(folder/'execution-evidence.json')})
 reviews[arm]['sources']=[source(folder,'final.patch',['combine_enabled','combine_hint','__is_filtered','FilterResult','fn __enabled','current_span','snapshot','revision','None =>','with_filter']),source(folder,'provider-attempts.json',['raw_output']),{'file':str(folder/'actor-events.jsonl'),'event_lines':[37,41,63,82] if arm=='L1' else [37,46,59,72,99,153]}]
 logs=ROOT/'evaluation/tracing-1523'/arm
 reviews[arm]['probe_evidence']=[]
 for p in sorted(logs.glob('contract_*.txt')):
  for n,l in enumerate(p.read_text(encoding='utf-8-sig',errors='replace').splitlines(),1):
   if 'PROBE_RESULT' in l: reviews[arm]['probe_evidence'].append({'file':str(p),'line':n,'result':l})
save(ROOT/'code-review.json',{'method':'已知配置的 Codex 語意覆核：閱讀原任務、完整命令、完整修改、新增測試、既有呼叫路徑與六份提醒，依完整流程的責任與固定行為證據判斷；未新增匿名模型評審，不把失敗答案當品味勝負對照。執行契約與功能交付分開判定。','new_model_judge_calls':0,'trials':reviews})
print('Recorded execution and code reviews for L1/L2; Actor artifacts unchanged.')
