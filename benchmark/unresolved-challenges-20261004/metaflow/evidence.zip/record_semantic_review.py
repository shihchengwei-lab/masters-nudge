"""Record Codex's semantic review of the preserved answers; no judge calls."""
from pathlib import Path
import json
import pipeline

ROOT = Path(__file__).resolve().parent
CASE = 'fb-metaflow-stubs'
reviews = {
    'K1': {
        'quality': '局部結構有改善；整體交付仍不完整，不能評為高品味的完成答案。',
        'structure': '以同一成員的 annotation 與 descriptor 組成一筆資料，讓 descriptor 決定 property/setter 宣告，annotation 只補缺少的型別；所有一般函式、property accessor 與 Metaflow 補充共用簽章集合。這兩項直接減少資訊被不同路徑覆蓋的責任，沒有另建大型框架。但 None 在函式參數的呼叫端仍與「沒有型別」混同，Annotated 的 opaque metadata 直接 repr 也未保證可生成合法程式。',
        'findings': [
            '固定保留測試45項通過；annotation/class/function/reset介面與文件引號、TypedDict鍵檢查通過。完整完成仍失敗，metaflow_members_input.py 與 metaflow_review_members_input.py 未通過。',
            'def f(x: None) -> None 的參數產生成 def f(x) -> None；_exploit_annotation(None) 按介面應回傳空字串，但函式產生器未先將明確 None 型別轉為 type(None)，遺失原任務要求的參數註記。',
            'typing.Annotated[int, object()] 的 metadata 直接 repr 產生 <object object at ...>，不是合法 Python 表達式，固定檢查得到 SyntaxError。這不是只有字串格式不同，而是描述檔無法解析。',
            '多載擷取、預設值與文件格式的小 helper 共用同一輸出流程；新增部署器特定分支有既有動態 API 依據，不因分支多就判高品味或過度設計。局部成功不能抵銷失效輸出。',
        ],
        'adoption': {
            'classification': '3/3送達提醒實際採納',
            'explanation': '三則分別要求 annotation+descriptor 同筆保留、accessor 多載集合、Metaflow 補充逐一套在完整簽章集合。最終 members 配對資料、_function_signatures 及 documented_signatures 均落實；不是只跑檢查。事件47、58、63及後續修改確認方向，不能因此宣稱整題完成。',
        },
        'evidence': [
            'runs/fb-metaflow-stubs/K1/actor-events.jsonl:47,58,63,65,67,105',
            'runs/fb-metaflow-stubs/K1/review-source.py.txt:676,760,820,908,1022,1032,1358',
            'evaluation/fb-metaflow-stubs/K1/reserved.txt',
            'evaluation/fb-metaflow-stubs/K1/metaflow_members_input.py.txt',
            'evaluation/fb-metaflow-stubs/K1/metaflow_review_members_input.py.txt',
            'runs/fb-metaflow-stubs/K1/provider-attempts.json',
        ],
    },
    'K2': {
        'quality': '局部結構有改善；整體仍會遺漏成員或無限遞迴，未完成交付。',
        'structure': 'TypedDict欄位明確拆成型別與Required/NotRequired/未標記三態，再以鍵集合補未標記欄位，避免延後註記被反轉；部署器先探索provider、flow及trigger回傳型別才渲染，去除原本依賴走訪順序的補救。兩者都是可檢查且有承重的局部關係。類別輸出卻仍將annotation名單當成已完成名單，遮掉描述器；又將所有class-valued attribute當巢狀類別，未區分引用與所有權。',
        'findings': [
            '固定保留測試44通過1失敗：既有 _get_element_name_with_module 的 nested-class 命名行為改為包含OuterClass，違反封存相容性測試。此處記實際測試結果，不把較長名稱本身當成品味退步的證明。',
            '同名 annotation+property 的成員因 member_name in annotations 被跳過，只留下 value: int，失去property與setter；NamedTuple annotations重建為_fields時也丟掉額外註記。固定members檢查均確認。',
            'Node.alias = Node 會被當成巢狀類別再次產生，固定review_members檢查觸發RecursionError。需要區分真正的巢狀定義與指向既有類別的值；這是結構關係混同。',
            '明確None參數型別與Opaque Annotated metadata的合法語法已處理；TypedDict繼承及鍵檢查通過。但這些通過項不能消除另一條成員生成路徑的資訊遺失。',
        ],
        'adoption': {
            'classification': '3/3送達提醒實際採納；另1次靜默',
            'explanation': '第一則落實逐鍵Required/NotRequired；第二則用_typed_dict_annotation保留明示三態，未解析型別也保留限定符；第三則在_get_deployer_signatures先探索完整provider資料再生成簽章。事件51、64、81及新增相應行為測試支持實際改碼採納。提醒都集中在這些局部關係，沒有覆蓋剩餘property/self-alias失敗。',
        },
        'evidence': [
            'runs/fb-metaflow-stubs/K2/actor-events.jsonl:51,64,81,110',
            'runs/fb-metaflow-stubs/K2/review-source.py.txt:517,564,820,864,940,983',
            'evaluation/fb-metaflow-stubs/K2/reserved.txt',
            'evaluation/fb-metaflow-stubs/K2/metaflow_members_input.py.txt',
            'evaluation/fb-metaflow-stubs/K2/metaflow_review_members_input.py.txt',
            'runs/fb-metaflow-stubs/K2/provider-attempts.json',
        ],
    },
}
for arm in ('K1', 'K2'):
    folder = ROOT / 'runs' / CASE / arm
    audit = pipeline.read(folder / 'execution-evidence.json')
    assert not audit['existing_tests_changed'] and audit['actor_exit'] == 0
    assert not audit['other_tools'] and not audit['errors']
    execution = {
        'status': 'pass',
        'reason': '閱讀全部記錄命令、file_change與最終修改後，執行遵守既有測試不可改、checkout內實作、apply_patch編輯、不得安裝/網路/歷史/委派/提交之契約；也實際執行指定既有檢查與最終diff檢查。新增自己的測試允許。功能驗收失敗另列，不與執行行為混同；本輪Actor無三十分鐘截止。',
        'evidence': [
            {'task_clause': 'Existing tests are immutable; use apply_patch; all changes in this checkout', 'event_lines': [34, 39, 44, 49, 51, 55, 57, 60, 65, 67, 76, 82, 92, 99] if arm == 'K1' else [34, 41, 43, 50, 55, 61, 66, 70, 74, 85, 92, 94, 102], 'source': 'execution-evidence.json file_changes, existing_tests_changed=[], patch_paths'},
            {'task_clause': 'Do not commit, install packages, inspect Git history, use network, delegate or subagents', 'event_lines': [c['line'] for c in audit['commands']], 'source': '逐則閱讀完整commands；other_tools及errors為空。版本及格式查詢不是安裝或歷史檢索。'},
            {'task_clause': 'Inspect final diff and run relevant existing checks', 'event_lines': [104, 105] if arm == 'K1' else [104, 110, 112, 114], 'source': '原始actor-events.jsonl指定五個既有套件檢查及最終差異檢查'},
        ],
        'patch_sha256': pipeline.sha(folder / 'final.patch'),
        'execution_evidence_sha256': pipeline.sha(folder / 'execution-evidence.json'),
    }
    pipeline.save(folder / 'execution-review.json', execution)
pipeline.save(ROOT / 'code-review.json', {
    'method': '已知配置的Codex語意覆核：閱讀原任務、兩份完整實作修改、新增測試、既有呼叫流程、全部執行命令、原始提醒與固定驗收輸出。依完整流程的資料保留及維護責任判斷，不以抽象層次或測試數量獎勵，不把失敗答案作匿名勝負對照。review-source及normalized.diff只供換行正規化閱讀，正式答案為未修改final.patch。',
    'new_model_judge_calls': 0,
    'trials': reviews,
})
print(json.dumps({'execution_reviews': 2, 'code_review': True, 'new_model_judge_calls': 0}))
